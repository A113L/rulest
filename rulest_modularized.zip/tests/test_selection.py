"""Unit tests for rulest.selection: lazy-greedy (CELF) marginal-coverage
rule selection. Only select_rules_by_marginal_coverage is tested here — it
is pure CPU set-cover logic with no GPU dependency. evaluate_full_coverage
and compute_exact_recovery both require a real (or heavily mocked) GPU
engine and are exercised end-to-end instead, not unit tested here.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from rulest.selection import select_rules_by_marginal_coverage


def hits(*indices):
    """Shorthand for building a coverage array the way
    evaluate_full_coverage would (sorted-ish int32 array of hit indices)."""
    return np.array(indices, dtype=np.int32)


class TestSelectRulesByMarginalCoverage:

    def test_empty_coverage_returns_nothing(self):
        selected, covered = select_rules_by_marginal_coverage({}, {}, n_target_words=10)
        assert selected == []
        assert covered.dtype == bool
        assert covered.sum() == 0

    def test_rules_with_zero_hits_are_never_selected(self):
        coverage = {'a': hits(), 'b': hits(0, 1)}
        selected, covered = select_rules_by_marginal_coverage(coverage, {}, n_target_words=5)
        picked = [r for r, _ in selected]
        assert picked == ['b']
        assert covered.sum() == 2

    def test_picks_largest_coverage_first(self):
        # 'small' covers 1 word, 'big' covers 3 disjoint words — greedy must
        # pick 'big' first regardless of dict/insertion order.
        coverage = {
            'small': hits(0),
            'big': hits(1, 2, 3),
        }
        selected, covered = select_rules_by_marginal_coverage(coverage, {}, n_target_words=4)
        order = [r for r, _ in selected]
        assert order[0] == 'big'
        assert order == ['big', 'small']
        assert covered.sum() == 4

    def test_avoids_redundant_overlapping_rule(self):
        # 'a' and 'b' both cover the exact same 3 words (fully redundant);
        # 'c' covers 1 orthogonal word. With budget=2, the optimal union is
        # {a-or-b} + c (4 words), never a+b (which only ever recovers 3).
        coverage = {
            'a': hits(0, 1, 2),
            'b': hits(0, 1, 2),
            'c': hits(3),
        }
        selected, covered = select_rules_by_marginal_coverage(
            coverage, {}, n_target_words=4, budget=2)
        picked = {r for r, _ in selected}
        assert len(picked) == 2
        assert 'c' in picked  # the only source of word 3 — must be picked
        assert covered.sum() == 4  # full coverage achieved within budget 2

    def test_budget_limits_selection_count(self):
        coverage = {f'r{i}': hits(i) for i in range(10)}
        selected, covered = select_rules_by_marginal_coverage(
            coverage, {}, n_target_words=10, budget=3)
        assert len(selected) == 3
        assert covered.sum() == 3

    def test_saturation_stops_when_nothing_new_left(self):
        # 4 rules but the target space only has 2 distinct words. 'd' alone
        # covers both words, so greedy picks it first (largest gain) and
        # every remaining rule's marginal gain is then 0 — unbounded
        # selection (budget=None) must stop right there instead of
        # continuing to exhaust the candidate pool.
        coverage = {
            'a': hits(0),
            'b': hits(1),
            'c': hits(0),        # fully redundant with 'a'
            'd': hits(0, 1),     # covers everything by itself
        }
        selected, covered = select_rules_by_marginal_coverage(
            coverage, {}, n_target_words=2, budget=None)
        assert len(selected) == 1
        assert selected[0][0] == 'd'
        assert covered.sum() == 2

    def test_marginal_gain_values_are_reported_correctly(self):
        coverage = {
            'a': hits(0, 1, 2),
            'b': hits(2, 3),   # overlaps 'a' on word 2 -> marginal gain 1 after 'a'
        }
        selected, covered = select_rules_by_marginal_coverage(coverage, {}, n_target_words=4)
        gains = dict(selected)
        assert gains['a'] == 3
        assert gains['b'] == 1  # only word 3 is new once 'a' is already selected

    def test_tie_break_uses_counts_then_shorter_rule_then_lexicographic(self):
        # 'x y' and 'a' have identical coverage and would tie on gain alone;
        # counts favors 'a' (higher raw GPU frequency) as the deterministic
        # tie-break, matching the (-count, depth, rule) ordering used
        # elsewhere in rulest (e.g. minimize_by_signature).
        coverage = {'x y': hits(0), 'a': hits(0)}
        counts = {'x y': 5, 'a': 50}
        selected, _ = select_rules_by_marginal_coverage(coverage, counts, n_target_words=1)
        assert selected[0][0] == 'a'

    def test_cost_alpha_favors_shorter_chain_on_equal_gain(self):
        # Two rules give identical raw coverage; with cost_alpha>0 the
        # 3-token chain is penalized relative to the 1-token rule, so once
        # its lazily-recomputed gain drops it should no longer be picked
        # ahead of an equally-covering-but-cheaper alternative sharing the
        # same words. We check this by comparing selection with alpha=0
        # (order by raw gain, ties broken by counts/depth) vs alpha>0
        # (order should still put the shorter rule first even if counts
        # would have tie-broken the other way).
        coverage = {
            'z': hits(0, 1, 2, 3, 4),        # depth 1, 5 hits
            'w x y': hits(0, 1, 2, 3, 4),    # depth 3, same 5 hits
        }
        counts = {'z': 1, 'w x y': 1}
        selected_flat, _ = select_rules_by_marginal_coverage(
            coverage, counts, n_target_words=5, cost_alpha=0.0)
        selected_cost, _ = select_rules_by_marginal_coverage(
            coverage, counts, n_target_words=5, cost_alpha=1.0)
        # Under cost_alpha=1.0, gain(z) = 5/1 = 5 > gain(w x y) = 5/3 -> 'z' wins.
        assert selected_cost[0][0] == 'z'
        # Both should still recover everything (they cover the same words).
        assert selected_flat[0][0] in ('z', 'w x y')

    def test_covered_mask_shape_matches_n_target_words(self):
        coverage = {'a': hits(0, 4)}
        _, covered = select_rules_by_marginal_coverage(coverage, {}, n_target_words=7)
        assert covered.shape == (7,)
        assert covered.dtype == bool
        assert covered[0] and covered[4]
        assert not covered[1] and not covered[6]

    def test_selection_order_is_deterministic_across_runs(self):
        coverage = {
            'a': hits(0, 1),
            'b': hits(1, 2),
            'c': hits(3),
        }
        counts = {'a': 3, 'b': 3, 'c': 1}
        r1, _ = select_rules_by_marginal_coverage(coverage, counts, n_target_words=4)
        r2, _ = select_rules_by_marginal_coverage(coverage, counts, n_target_words=4)
        assert [r for r, _ in r1] == [r for r, _ in r2]


if __name__ == "__main__":
    import pytest
    print(f"Running {__file__} directly — use `pytest {__file__}` for full output.\n")
    raise SystemExit(pytest.main([__file__, "-v"]))
