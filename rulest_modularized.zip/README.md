# rulest — modularized

This is `rulest_v2.py` (the single-file GPU-compatible hashcat rules engine)
split into a proper package, with identical behavior. It was split by
extracting each top-level function/class along its exact original line
range and giving each group of related functionality its own module with
explicit imports — no code was rewritten, only relocated (with two
documented exceptions below for cross-module global state).

## Install

```bash
pip install -r requirements.txt
```

(`pyopencl` needs a working OpenCL ICD/driver on your system to actually
build; it's not required just to import the package or run `--help`.)

## Run

```bash
python3 run_rulest.py base_wordlist.txt target_wordlist.txt -o rules.txt
python3 run_rulest.py --list-devices
python3 run_rulest.py --help
```

Behaves identically to the original `rulest_v2.py` — same CLI flags, same
output format, same banner.

## Module layout

| Module | Contents |
|---|---|
| `rulest/state.py` | Mutable runtime flags (`VERBOSE`, `ALLOW_REJECT_RULES`) set by the CLI, read everywhere |
| `rulest/worker_state.py` | Shared globals for the Stage-0 multiprocessing workers (mutated from two modules — see docstring) |
| `rulest/common.py` | Colors/logging, the pause/resume keyboard controller, all constants, the hashcat rule validator, the CPU rule applicator, FNV-1a hashing |
| `rulest/minimize.py` | Signature-based functional rule minimization (in-memory + SQLite disk fallback) |
| `rulest/token_strip.py` | Stage 0: CPU exact-match pre-pass |
| `rulest/devices.py` | OpenCL device enumeration + dynamic batch/bloom-filter sizing |
| `rulest/kernel_source.py` | The atomic-rule-space generator + the OpenCL C kernel template |
| `rulest/gpu_engine.py` | Single-GPU OpenCL engine: compile/cache/retry, bloom filter, kernel launches, driver-hang recovery |
| `rulest/gpu_worker.py` | Process-isolated GPU worker (one OS process per device) for multi-GPU mode |
| `rulest/multi_gpu.py` | Fans work out across several `GPUEngine`/`ProcessEngineProxy` instances |
| `rulest/genetic.py` | Stage 3 (`--genetic`): diversity-aware genetic algorithm over rule chains |
| `rulest/extractor.py` | `GPUExtractor` — the pipeline orchestrator (Stage 0/1/S/2/3) |
| `rulest/io_utils.py` | Wordlist loading |
| `rulest/cli.py` | `main()` — argument parsing and the pipeline report/summary printing |
| `run_rulest.py` | Entry point (sets the `spawn` multiprocessing start method, then calls `cli.main()`) |
