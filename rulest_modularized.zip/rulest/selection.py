"""
Post-processing — marginal-coverage rule SELECTION.

minimize_by_signature() (see minimize.py) answers "which rules are
functionally distinct?" — it says nothing about which of those distinct
rules are actually worth keeping for a given budget. Sorting by raw GPU
frequency (the historical default) picks rules that individually recover
the most target words, but says nothing about *overlap*: two high-frequency
rules can recover almost the same subset of the target list, in which case
keeping both wastes budget that a lower-frequency-but-orthogonal rule would
have spent better.

The functions below implement "select by marginal coverage, not by summed
score": build the real coverage matrix C(r) = {base words that, once
mutated by rule r, hit the target bloom filter} against the actual
--target-hours target wordlist (not the tiny BUILTIN_PROBES set used for
signature dedup), then run a lazy greedy (CELF) set-cover selection over
it. This reuses GeneticRuleEvolver's existing GPU dispatch (single-GPU or
MultiGPU fan-out via evaluate_population) instead of duplicating
kernel-launch code — it's the same "chains x words -> hit set" computation
the GA already does per-generation, just run once over the whole candidate
pool.
"""
import time
import heapq
import shutil

import numpy as np
from tqdm import tqdm

from .common import log_info, log_warn, log_section, bold, green, cyan, _fmt_speed
from .genetic import GeneticRuleEvolver

# Shared empty-hit sentinel (avoids allocating a fresh empty array per rule
# with zero coverage — there are often many of these in a large pool).
_EMPTY_HITS = np.empty(0, dtype=np.int32)


def evaluate_full_coverage(gpu_engine, base_words, target_words, rules, max_depth, batch_size=4000):
    """GPU-evaluate every candidate rule in `rules` by applying it to
    `base_words` and checking hits against the `target_words` bloom filter,
    returning the coverage matrix as {rule_str: np.ndarray(int32)} (sorted
    hit indices into base_words — not a Python set/frozenset; see note
    below on why).

    `rules` should be the post-minimize_by_signature candidate pool (already
    functionally deduped against BUILTIN_PROBES) — this step is what tells
    you, for each *distinct* rule, exactly which real target-wordlist entries
    it actually cracks, which BUILTIN_PROBES-based dedup cannot answer.

    Two things this function does that a naive "just call evaluate_population
    in a loop" version wouldn't:

    1. Rules are processed shortest-chain-first. The candidate pool comes out
       of final_counts (a Counter) in insertion order — Stage 1 (depth 1) ->
       Stage S -> Stage 2 (depth 2..N, growing) -> Stage 3 GA (often the
       deepest chains). Every extra token in a chain is extra per-word work
       in the OpenCL kernel, so processing in that order means throughput
       (rules/s) silently degrades as the run progresses even though nothing
       is actually wrong — it looks like a stall but is really "later batches
       cost more per rule". Sorting by depth first makes the tqdm ETA
       meaningful and front-loads the cheap, high-volume work.
    2. Coverage is stored as compact int32 numpy arrays, not
       frozenset(python int). A Python frozenset of boxed ints costs roughly
       50-100+ bytes per element (object header + hash table slot); a numpy
       int32 array costs 4 bytes per element, contiguous. At hundreds of
       thousands of rules this is the difference between the process staying
       resident and it starting to swap/GC-thrash midway through a run —
       which is the *other* plausible explanation for throughput cratering
       partway through a long coverage-eval pass.
    """
    log_section("SELECTION — GPU Coverage Evaluation")
    rule_list = [r for r in rules if r and r != ':']
    # Stable sort: ties (same depth) keep their original relative order.
    rule_list.sort(key=lambda r: len(r.split()))
    n = len(rule_list)
    log_info(f"[COVERAGE] Candidates   : {bold(str(n))}")
    log_info(f"[COVERAGE] Base words   : {bold(str(len(base_words)))}")
    log_info(f"[COVERAGE] Target words : {bold(str(len(target_words)))}")
    if n == 0 or not target_words or not base_words:
        return {}

    try:
        import resource
        def _rss_mb():
            # ru_maxrss is KB on Linux, bytes on macOS — Linux is the
            # realistic deployment target here (OpenCL + GPU box).
            return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    except ImportError:
        def _rss_mb(): return -1.0

    # A throwaway GeneticRuleEvolver instance purely as a GPU-dispatch shim:
    # rule_pool=[] because we never call evolve()/mutate on it, only
    # evaluate_population(), which is what fans batches across engines
    # (single GPU or MultiGPU) and returns {chain_str: set(local_word_index)}.
    #
    # IMPORTANT: base_words here, not target_words. Rules are applied to
    # base_words (the small dictionary/wordlist) and checked against the
    # bloom filter that was already built from target_words on the GPU
    # engine (loaded earlier in extract_rules()). Passing target_words as
    # both the words-to-transform *and* the membership set is wrong twice
    # over: semantically (target-vs-target instead of base-vs-target) and
    # performance-wise (every one of the candidate rules gets applied to
    # all of target_words instead of the usually much smaller base_words,
    # which is the actual cause of an x2-x10 slowdown / RSS growth at
    # multi-million-word targets). Returned hit indices are indices into
    # base_words.
    evolver = GeneticRuleEvolver(gpu_engine, base_words, rule_pool=[], max_depth=max(2, max_depth))
    evolver.active_words = base_words

    coverage = {}
    ncols = shutil.get_terminal_size((80, 24)).columns
    t0 = time.time()
    with tqdm(total=n, desc=green("  Coverage eval"), unit="rule", ncols=ncols,
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}") as pbar:
        for i in range(0, n, batch_size):
            chunk = rule_list[i:i + batch_size]
            population = [tuple(r.split()) for r in chunk]
            hit_words = evolver.evaluate_population(population)
            for r, tok in zip(chunk, population):
                cs = ' '.join(tok)
                hits = hit_words.get(cs)
                coverage[r] = np.fromiter(hits, dtype=np.int32, count=len(hits)) if hits else _EMPTY_HITS
            # This is a one-shot full pass, not a GA loop reusing the same
            # active_words across many generations — the per-chain hit cache
            # buys nothing here (every rule is only ever evaluated once) and
            # would otherwise grow unboundedly across a 500k+ rule pool.
            evolver._hit_cache.clear()
            pbar.update(len(chunk))
            elapsed = time.time() - t0
            spd = _fmt_speed(pbar.n / elapsed if elapsed > 0 else 0, "rules")
            avg_depth = sum(len(r.split()) for r in chunk) / len(chunk)
            pbar.set_postfix({"spd": green(spd), "depth": f"{avg_depth:.1f}",
                               "rss": f"{_rss_mb():.0f}MB"}, refresh=False)
    covered_any = sum(1 for c in coverage.values() if len(c))
    log_info(f"[COVERAGE] {green('Done')}  rules with >=1 hit: {bold(cyan(str(covered_any)))}/{n}")
    return coverage


def select_rules_by_marginal_coverage(coverage, counts, n_target_words, budget=None, cost_alpha=0.0):
    """Lazy greedy (CELF) submodular set-cover selection.

    Instead of ranking rules by their own score and summing:
        score(r1) + score(r2) + ... + score(rk)
    this maximizes the *union* actually recovered:
        | C(r1) u C(r2) u ... u C(rk) |
    by repeatedly picking the rule with the largest NEW recovery given what's
    already selected. Naive greedy is O(rules x budget); CELF exploits
    submodularity (marginal gains only ever shrink as the covered set grows)
    to lazily re-validate the heap top instead of rescanning every rule each
    step, which is what makes this tractable at 150k-1.7M candidate rules.

    `coverage`: {rule: np.ndarray(int32 word_idx)} from evaluate_full_coverage().
    `counts`:   {rule: raw_gpu_frequency} — used only to break ties
                deterministically, never as the optimization objective.
    `n_target_words`: size of the boolean "covered" mask — len(base_words),
                since coverage indices from evaluate_full_coverage address
                base_words (the words that were transformed and tested
                against the target bloom filter), not target_words itself.
    `budget`:   max rules to select; None = run to saturation (stop once no
                remaining rule adds anything).
    `cost_alpha`: gain(r) = new_recovery(r) / depth(r)**cost_alpha. 0 = pure
                marginal-coverage greedy. >0 favors shorter/cheaper chains
                among rules with similar marginal gain.

    Coverage sets are tracked as a single numpy boolean mask over base_words
    (updated in place with fancy indexing) rather than Python set unions —
    with 150k-1.7M candidates this avoids repeated hashing and boxed-int set
    churn, matching the same memory rationale as switching
    evaluate_full_coverage's storage from frozenset to int32 arrays.

    Returns (selected, covered_mask):
        selected     -> list of (rule, marginal_gain) in selection order (best first)
        covered_mask -> np.ndarray(bool), True at every base-word index
                        recovered by `selected`
    """
    def cost(r):
        if cost_alpha <= 0:
            return 1.0
        depth = max(1, len(r.split()))
        return depth ** cost_alpha

    log_section("SELECTION — Greedy Marginal Coverage (CELF)")
    rule_order = sorted(
        (r for r, c in coverage.items() if len(c)),
        key=lambda r: (-counts.get(r, 0), len(r.split()), r)
    )
    limit = budget if budget else len(rule_order)
    log_info(f"[SELECT] Candidates (with >=1 hit) : {bold(str(len(rule_order)))}")
    log_info(f"[SELECT] Budget                    : {bold(str(limit) if budget else 'unbounded (saturation)')}")
    log_info(f"[SELECT] Cost alpha                : {bold(str(cost_alpha))}")

    heap = []
    for r in rule_order:
        c = coverage[r]
        heapq.heappush(heap, (-(len(c) / cost(r)), r, 0))

    selected = []
    covered_mask = np.zeros(n_target_words, dtype=bool)
    n_covered = 0
    stamp = 0
    ncols = shutil.get_terminal_size((80, 24)).columns
    with tqdm(total=limit, desc=green("  Greedy select"), unit="rule", ncols=ncols,
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}") as pbar:
        while heap and len(selected) < limit:
            neg_gain, r, s = heapq.heappop(heap)
            if s == stamp:
                gain = -neg_gain
                if gain <= 0:
                    break  # saturation: nothing left adds any new coverage
                selected.append((r, gain))
                covered_mask[coverage[r]] = True
                n_covered = int(covered_mask.sum())
                stamp += 1
                pbar.update(1)
                pbar.set_postfix({"recovered": cyan(str(n_covered))}, refresh=False)
                continue
            c = coverage[r]
            new_gain = int(np.count_nonzero(~covered_mask[c])) / cost(r)
            if new_gain <= 0:
                continue
            heapq.heappush(heap, (-new_gain, r, stamp))

    log_info(f"[SELECT] {green('Done')}  rules selected: {bold(cyan(str(len(selected))))}  "
              f"recovered: {bold(cyan(str(n_covered)))}")
    return selected, covered_mask


def compute_exact_recovery(gpu_engine, base_words, target_words, selected, coverage, batch_size=200000):
    """--exact-recovery: re-verify the SELECTED (small) ruleset's real GPU
    output against an exact (non-bloom, zero-FPR) set of target_words.

    During selection, `coverage[rule]` only tells us "this base_word,
    mutated by this rule, passed the bloom filter" — it never tells us
    WHICH target_words entry matched, and bloom filters have a nonzero false
    positive rate. This re-applies just the selected rules to just the
    base_words already flagged as hits (a small, already-bounded set — not a
    full rules x base_words sweep), retrieves the actual output string via
    verify_pairs_exact(), and checks it against a real Python set of
    target_words. That gives the true count of DISTINCT target_words
    entries cracked, and filters out any bloom false positives that made it
    into `coverage`.

    Returns (n_exact_covered, recovery_pct, matched_target_strings).
    """
    log_section("SELECTION — Exact-Match Verification (--exact-recovery)")
    selected_chains = [r for r, _ in selected]
    if not selected_chains:
        log_info("[EXACT] No selected rules — nothing to verify")
        return 0, 0.0, set()

    pairs = []
    for ci, r in enumerate(selected_chains):
        hits = coverage.get(r)
        if hits is None or len(hits) == 0:
            continue
        for wi in hits.tolist():
            pairs.append((ci, int(wi)))
    log_info(f"[EXACT] Pairs to verify : {bold(str(len(pairs)))}  (from {len(selected_chains)} selected rules)")
    if not pairs:
        return 0, 0.0, set()

    outputs = gpu_engine.verify_pairs_exact(base_words, selected_chains, pairs, batch_size=batch_size)

    target_set = set(target_words)
    matched = set()
    fp_bloom = 0
    for out in outputs:
        if out is None:
            continue
        if out in target_set:
            matched.add(out)
        else:
            fp_bloom += 1

    n_target_unique = len(target_set)
    recovery_pct = len(matched) / max(1, n_target_unique)
    if fp_bloom:
        log_warn(f"[EXACT] {fp_bloom} bloom false positive(s) filtered out of coverage")
    log_info(f"[EXACT] {green('Done')}  distinct target_words cracked: "
             f"{bold(cyan(str(len(matched))))}/{n_target_unique} ({recovery_pct:.2%})")
    return len(matched), recovery_pct, matched
