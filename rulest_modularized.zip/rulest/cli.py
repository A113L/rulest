"""
Command-line entry point: argument parsing and the Stage 0/1/S/2/3 pipeline
summary/report printing that wraps GPUExtractor.extract_rules().
"""
import os
import sys
import gc
import time
import shutil
import argparse
import datetime
import multiprocessing as mp
from collections import defaultdict

from . import state
from .common import (
    print_banner, _print_controls, log_info, log_warn, log_error,
    bold, cyan, green, yellow, red, dim, _kb, safe_worker_count,
    MAX_HASHCAT_CHAIN, MINIMIZE_DISK_THRESHOLD, BUILTIN_PROBES,
)
from .devices import list_devices
from .extractor import GPUExtractor
from .multi_gpu import MultiGPUEngine
from .minimize import minimize_by_signature
from .io_utils import load_wordlist

def main():
    ap = argparse.ArgumentParser(prog='rulest', description='GPU-Compatible Hashcat Rules Engine (optimized)',
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('base_wordlist', nargs='?')
    ap.add_argument('target_wordlist', nargs='?')
    ap.add_argument('-o','--output', default='rulest_output.txt')
    ap.add_argument('--device', default=None, metavar='SPEC',
                    help='Device index, name substring, "all" to run every detected GPU in parallel, '
                         'or a comma-separated list of indices (e.g. "0,1") to run only those GPUs in parallel '
                         '(default: auto-select best single GPU)')
    ap.add_argument('--list-devices', action='store_true')
    ap.add_argument('--max-depth', type=int, default=2)
    ap.add_argument('--target-hours', type=float, default=0.5)
    ap.add_argument('--max-chains', type=int, default=0)
    ap.add_argument('--bloom-mb', type=int, default=0)
    ap.add_argument('--bloom-no-shard', action='store_true')
    ap.add_argument('--seed-rules', default=None)
    for i in range(2,11):
        ap.add_argument(f'--depth{i}-chains', type=int, default=None, dest=f'depth{i}_chains')
    ap.add_argument('--allow-reject-rules', action='store_true')
    ap.add_argument('--no-builtin-seeds', action='store_true')
    pt = ap.add_argument_group('STAGE 0 — Token-Strip')
    pt.add_argument('--token-strip', action='store_true')
    pt.add_argument('--token-strip-min-stem', type=int, default=4)
    pt.add_argument('--token-strip-max-prefix', type=int, default=4)
    pt.add_argument('--token-strip-max-suffix', type=int, default=4)
    pt.add_argument('--token-strip-min-leet-amb', type=int, default=3)
    pt.add_argument('--token-strip-workers', type=int, default=0)
    pt.add_argument('--token-strip-chunk-size', type=int, default=0)
    ga = ap.add_argument_group('Genetic Algorithm')
    ga.add_argument('--genetic', action='store_true')
    ga.add_argument('--genetic-generations', type=int, default=50)
    ga.add_argument('--genetic-pop', type=int, default=200)
    ga.add_argument('--genetic-elite', type=float, default=0.15)
    ap.add_argument('--debug', action='store_true')
    args = ap.parse_args()

    state.ALLOW_REJECT_RULES = args.allow_reject_rules
    state.VERBOSE = args.debug
    print_banner()
    _print_controls()
    if args.list_devices: list_devices(); sys.exit(0)
    if not args.base_wordlist or not args.target_wordlist:
        ap.print_help(); print(); log_error("Both BASE and TARGET wordlists required"); sys.exit(1)
    if args.max_depth > MAX_HASHCAT_CHAIN:
        log_warn(f"Depth capped to {MAX_HASHCAT_CHAIN}"); args.max_depth=MAX_HASHCAT_CHAIN
    elif args.max_depth<1: log_error("--max-depth >=1"); sys.exit(1)

    log_info(f"  base      : {bold(args.base_wordlist)}")
    log_info(f"  target    : {bold(args.target_wordlist)}")
    shard_note = yellow('[sharding forced off]') if args.bloom_no_shard else dim('(auto: shard if >512MB)')
    log_info(f"  depth     : {bold(str(args.max_depth))}  |  hours: {bold(str(args.target_hours))}  |  bloom: {bold(str(args.bloom_mb or 'auto'))}MB  {dim('(GPU-only)')}  {shard_note}")
    if args.seed_rules: log_info(f"  seeds     : {bold(args.seed_rules)}")
    print()

    _EXCL = dim('[time budget: excluded]')
    _INCL = dim('[time budget: included]')

    if args.token_strip:
        _inj = green('→ STAGE S sbd → STAGE 2') if not args.no_builtin_seeds else yellow('→ STAGE 1 only → STAGE 2')
        log_info(f"  {bold(cyan('STAGE 0'))}  : {green('enabled')} — CPU exact-match (core+insert)  min-stem={args.token_strip_min_stem}  prefix={args.token_strip_max_prefix}  suffix={args.token_strip_max_suffix}  leet-amb={args.token_strip_min_leet_amb}  workers={safe_worker_count(args.token_strip_workers or mp.cpu_count())}  {_inj}  {_EXCL}")
    else:
        log_info(f"  {bold(dim('STAGE 0'))}  : {red('disabled')}")

    log_info(f"  {bold(cyan('STAGE 1'))}  : {green('enabled')} — single-rule GPU sweep  {_INCL}")

    if not args.no_builtin_seeds:
        log_info(f"  {bold(cyan('STAGE S'))}  : {green('enabled')} — numeric/pattern seed families A-M  {_EXCL}")
    else:
        log_info(f"  {bold(dim('STAGE S'))}  : {red('disabled')}  (--no-builtin-seeds)")

    log_info(f"  {bold(cyan('STAGE 2'))}  : {green('enabled')} — rule-chain GPU search  depth 2-{args.max_depth}  {_INCL}")

    if args.genetic:
        if not 0.0<args.genetic_elite<1.0: log_error("--genetic-elite must be between 0 and 1"); sys.exit(1)
        log_info(f"  {bold(cyan('STAGE 3'))}  : {green('enabled')} — genetic algorithm  pop={args.genetic_pop}  gen={args.genetic_generations}  elite={args.genetic_elite:.0%}  {_INCL}")
    else:
        log_info(f"  {bold(dim('STAGE 3'))}  : {red('disabled')}  (--genetic to enable)")
    print()

    base_words = load_wordlist(args.base_wordlist)
    target_words = load_wordlist(args.target_wordlist)
    print()

    _kb.start()
    t_start = time.time()
    extractor = GPUExtractor(
        len(base_words), len(target_words), args.max_depth, args.device,
        args.target_hours, args.max_chains, args.seed_rules, args.bloom_mb,
        builtin_seeds=not args.no_builtin_seeds,
        bloom_no_shard=args.bloom_no_shard, genetic=args.genetic,
        genetic_generations=args.genetic_generations, genetic_pop=args.genetic_pop,
        genetic_elite=args.genetic_elite, token_strip=args.token_strip,
        token_strip_min_stem=args.token_strip_min_stem,
        token_strip_max_prefix=args.token_strip_max_prefix,
        token_strip_max_suffix=args.token_strip_max_suffix,
        token_strip_min_leet_amb=args.token_strip_min_leet_amb,
        token_strip_workers=args.token_strip_workers,
        token_strip_chunk_size=args.token_strip_chunk_size,
    )
    depth_overrides = {f'depth{i}_override': getattr(args, f'depth{i}_chains') for i in range(2,11)}
    try:
        raw_counts = extractor.extract_rules(base_words, target_words, **depth_overrides)
    finally:
        if isinstance(extractor.gpu_engine, MultiGPUEngine):
            extractor.gpu_engine.shutdown()
    _kb.stop()
    del target_words
    gc.collect()
    if _kb.quit_requested: log_warn("[QUIT]  Early exit — saving partial results")
    log_info(f"\n[GPU]  Raw bloom-filter candidates: {bold(cyan(str(len(raw_counts))))}"); print()

    final_counts = minimize_by_signature(raw_counts, BUILTIN_PROBES)
    if ':' not in final_counts: final_counts[':'] = 0

    depth_dist = defaultdict(int)
    for r in final_counts:
        if r != ':': depth_dist[len(r.split())] += 1
    ds = '  '.join(f"d{d}:{depth_dist[d]:,}" for d in sorted(depth_dist))
    final_rules = len(final_counts) - (1 if ':' in final_counts else 0)
    removed = len(raw_counts) - len(final_counts)

    si = sorted(final_counts.items(), key=lambda kv: (-kv[1], len(kv[0].split()), kv[0]))
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write("# rulest — GPU-Compatible Hashcat Rules Engine (optimized)\n")
        f.write(f"# Generated      : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"# Base           : {os.path.basename(args.base_wordlist)}\n")
        f.write(f"# Target         : {os.path.basename(args.target_wordlist)}\n")
        f.write(f"# Depth          : 1-{args.max_depth}\n")
        bloom_mb = args.bloom_mb if args.bloom_mb>0 else "auto"
        f.write(f"# Bloom          : {bloom_mb} MB  (sharding: {'disabled' if args.bloom_no_shard else 'auto'})\n")
        f.write(f"# STAGE 0        : core + insert mode  GPU-verified candidates\n")
        if args.genetic:
            f.write(f"# STAGE 3 GA     : pop={args.genetic_pop}  gen={args.genetic_generations}  elite={args.genetic_elite:.0%}\n")
        f.write("#\n")
        f.write(f"# GPU raw candidates      : {len(raw_counts):,}\n")
        mp2 = 'disk-backed SQLite' if len(raw_counts) > MINIMIZE_DISK_THRESHOLD else 'in-memory'
        f.write(f"# Minimization            : {mp2}  (threshold {MINIMIZE_DISK_THRESHOLD:,})\n")
        f.write(f"#   Probe words           : {len(BUILTIN_PROBES)}  (built-in)\n")
        f.write(f"#   Equiv. rules removed  : {removed:,}\n")
        f.write("#\n")
        f.write(f"# Rules kept     : {final_rules:,}  ({ds})\n")
        f.write(f"# Sorted by      : GPU frequency (descending, UTF-8)\n")
        f.write(":\n")
        for r,_ in si:
            if r!=':': f.write(f"{r}\n")
    log_info(f"[OUT]  Minimized rules written to: {bold(args.output)}")

    elapsed = time.time()-t_start
    sep = '─' * shutil.get_terminal_size((80,24)).columns
    print()
    log_info(cyan(sep))
    log_info(f"  {bold('DONE')}  rulest finished in {bold(f'{elapsed:.1f}s')}")
    log_info(cyan(sep))
    log_info(f"  GPU raw candidates : {bold(str(len(raw_counts)))}")
    log_info(f"  Rules kept         : {bold(green(str(final_rules)))}  {dim('('+ds+')')}")
    log_info(f"  Rules removed      : {bold(red(str(removed)))}")
    log_info(f"  Output file        : {bold(args.output)}")
    log_info(cyan(sep))
    top = sorted([(r,c) for r,c in final_counts.items() if r!=':'], key=lambda kv:(-kv[1],len(kv[0].split()),kv[0]))[:20]
    if top:
        print(); log_info(f"  Top {len(top)} rules by GPU frequency:")
        for i,(r,c) in enumerate(top,1):
            log_info(f"  {dim(str(i).rjust(3)+'.')}  {dim(f'd={len(r.split())}')}  {r:<42s}  {cyan(str(c))}")
    print()
