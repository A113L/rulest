"""
rulest - GPU-Compatible Hashcat Rules Engine (modularized package).

This package is a straight module-split of the original single-file
rulest_v2.py, refactored into logical units for readability and testing.
Behavior is unchanged; see rulest.cli.main() for the CLI entry point,
which is also exposed as the `rulest` console script (see run_rulest.py).
"""
