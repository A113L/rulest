"""Wordlist loading."""
import os
import sys

from .common import log_info, log_error, bold, cyan, MAX_WORD_LEN

def load_wordlist(filename):
    words = set()
    try:
        with open(filename, 'rb') as f:
            data = f.read()
        for line in data.split(b'\n'):
            w = line.decode('latin-1', errors='ignore').strip()
            if w and len(w) <= MAX_WORD_LEN:
                words.add(w)
    except FileNotFoundError:
        log_error(f"File not found: {filename}"); sys.exit(1)
    res = list(words)
    log_info(f"[LOAD] {bold(os.path.basename(filename))}: {bold(cyan(f'{len(res):,}'))} unique words")
    return res
