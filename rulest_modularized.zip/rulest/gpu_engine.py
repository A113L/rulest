"""
Single-GPU OpenCL engine: kernel compile/cache/retry, bloom-filter build and
upload, and the single-rule / rule-chain search kernels launches. Also owns
driver-hang recovery (kernel build timeout + retry with the optimizer
disabled, and full context recreation after a fatal kernel error).
"""
import time
import shutil
import random
import threading
import itertools
from collections import Counter, defaultdict

import numpy as np
import pyopencl as cl
from tqdm import tqdm

from .common import (
    log_info, log_warn, log_error, log_debug, bold, green, cyan, _kb,
    fnv1a_32, HashcatRuleValidator, _fmt_speed,
    MAX_WORD_LEN, MAX_RULE_LEN, MAX_OUTPUT_LEN, MAX_CHAIN_STRING_LEN,
    MAX_HASHCAT_CHAIN, BLOOM_HASH_FUNCTIONS, HOT_RULE_RATIO,
    MAX_ATTEMPTS_MULTIPLIER, _BLOOM_ALREADY_ON_GPU,
    FNV1A_SEED1, FNV1A_SEED2, SPECIAL_CHARS_TOP, SPECIAL_CHARS_CORE, LEET_OPS,
)
from .devices import estimate_free_vram, get_max_allocation, get_device_by_spec
from .kernel_source import GPU_KERNEL_TEMPLATE

class _KernelBuildTimeout(Exception):
    """Raised by GPUEngine._safe_build_program when the OpenCL driver's
    build() call doesn't return within the watchdog timeout."""
    pass

class GPUEngine:
    def __init__(self, params):
        self.params = params
        self.context = self.queue = self.device = self.program = None
        self.max_work_group_size = 512
        self.local_work_size = params.get('LOCAL_WORK_SIZE', 512)
        self.bloom_buf = None
        self.bloom_np = None
        self.rule_index = {}
        self.gpu_rules = []
        self.kernel_single = None
        self.kernel_chain = None
        self.kernel_bloom = None
        self.kernel_verify = None
        self._consecutive_errors = 0
        self._MAX_CONSECUTIVE_ERRORS = 5
        self._cached_free_vram = None
        self._cached_max_alloc = None
        self.disabled = False  # set True if a kernel build hangs/times out — this
                                # device's driver may be stuck holding an internal
                                # lock, so we stop issuing further work to it rather
                                # than risk every subsequent call blocking forever.
        self._program_cache = {}  # MAX_CHAIN_DEPTH -> (program, kernel_single, kernel_chain, kernel_bloom, kernel_verify)
        self._rules_buf = None
        self._rules_offsets_buf = None
        self._rules_lengths_buf = None
        self._rules_buf_key = None
        self._bloom_recovery_fn = None
        self._compiled_depth = None   # track compiled MAX_CHAIN_DEPTH
        self._base_words_precomputed = None  # (wf, wo, wl)

    def get_free_vram(self): return estimate_free_vram(self.device)
    def get_max_allocation(self): return get_max_allocation(self.device)

    def _refresh_cached_limits(self):
        self._cached_free_vram = estimate_free_vram(self.device)
        self._cached_max_alloc = get_max_allocation(self.device)

    def safe_output_buffer_size(self, words_count, chains_count):
        fv = self._cached_free_vram or self.get_free_vram()
        ma = self._cached_max_alloc or self.get_max_allocation()
        avail = min(fv, ma) - 5*1024**2
        # Must match the kernel constant MAX_CHAINS_TO_FIND = MAX_SAFE_RESULTS_PER_BATCH;
        # do NOT cap below that value or the kernel will write past the end of fo.
        return max(1, min(avail//MAX_CHAIN_STRING_LEN,
                          self.params['MAX_SAFE_RESULTS_PER_BATCH'],
                          words_count*chains_count))

    def initialize_gpu(self, device_spec):
        try:
            self.device = get_device_by_spec(device_spec)
            self.context = cl.Context([self.device])
            self.queue = cl.CommandQueue(self.context)
            self.max_work_group_size = self.device.get_info(cl.device_info.MAX_WORK_GROUP_SIZE)
            self.local_work_size = min(self.local_work_size, self.max_work_group_size)
            while self.max_work_group_size % self.local_work_size != 0 and self.local_work_size > 32:
                self.local_work_size //= 2
            self._refresh_cached_limits()
            log_info(f"[GPU]  {bold(self.device.name.strip())}")
            vgb = self._cached_free_vram/1024**3
            log_debug(f"       WGS={self.local_work_size}, VRAM~{vgb:.1f}GB, CU={self.device.get_info(cl.device_info.MAX_COMPUTE_UNITS)}")
            return True
        except Exception as e: log_error(f"GPU init failed: {e}"); return False

    def compile_kernel(self, force=False):
        current_depth = self.params.get('MAX_CHAIN_DEPTH', 2)
        if not force and self.program is not None and self._compiled_depth == current_depth:
            log_debug("kernel already compiled with same depth")
            return self.program
        # Reuse a previously-built program for this exact depth if we have
        # one cached. The pipeline flips MAX_CHAIN_DEPTH back and forth
        # (e.g. Stage2 depth -> Seed-pass depth -> back to Stage2 depth), so
        # this avoids re-triggering a slow/flaky driver compile — a real fix
        # for the "hang after seed pass" case, since the Stage 2 recompile is
        # very often just reusing what was already built at pipeline start.
        cached = self._program_cache.get(current_depth)
        if cached is not None:
            self.program, self.kernel_single, self.kernel_chain, self.kernel_bloom, self.kernel_verify = cached
            self._compiled_depth = current_depth
            log_info(f"[GPU]  Reusing cached kernel for depth {current_depth} (skipping rebuild)")
            return self.program
        if self.program:
            log_info(f"[GPU]  Recompiling kernel for depth {current_depth} (was {self._compiled_depth})")
        else:
            log_info("[GPU]  Compiling kernel ...")
        try:
            src = GPU_KERNEL_TEMPLATE.format(
                BLOOM_FILTER_SIZE=self.params['BLOOM_FILTER_SIZE'],
                BLOOM_NUM_SHARDS=self.params['BLOOM_NUM_SHARDS'],
                BLOOM_SHARD_BITS=self.params['BLOOM_SHARD_BITS'],
                BLOOM_SHARD_BYTES=self.params['BLOOM_SHARD_BYTES'],
                MAX_SAFE_RESULTS_PER_BATCH=self.params['MAX_SAFE_RESULTS_PER_BATCH'],
                MAX_CHAIN_DEPTH=current_depth,
                MAX_CHAIN_STRING_LEN=MAX_CHAIN_STRING_LEN,
                MAX_WORD_LEN=MAX_WORD_LEN,
                MAX_RULE_LEN=MAX_RULE_LEN,
                MAX_OUTPUT_LEN=MAX_OUTPUT_LEN,
                BLOOM_HASH_FUNCTIONS=BLOOM_HASH_FUNCTIONS,
            )
        except Exception as e:
            log_error(f"Kernel compile failed: {e}")
            return None

        dev_name = self.device.name.strip() if self.device else "device"
        prog = None
        try:
            prog = self._safe_build_program(src, timeout=180)
        except _KernelBuildTimeout:
            # Many Intel NEO / iGPU driver hangs are caused by the optimizer
            # choking on a particular kernel rather than the device being
            # truly broken. Give it one real second chance on a brand-new
            # context (the old one may still have a build stuck inside it)
            # with the optimizer disabled — this is a well-known practical
            # workaround for exactly this class of hang.
            log_warn(f"[GPU]  Build stalled on {dev_name} — retrying once on a fresh context "
                     f"with the optimizer disabled (-cl-opt-disable)")
            if self._recreate_context():
                try:
                    prog = self._safe_build_program(src, timeout=120, build_options=['-cl-opt-disable'])
                except _KernelBuildTimeout:
                    prog = None
                except Exception as e:
                    log_error(f"[GPU]  Retry build failed on {dev_name}: {e}")
                    prog = None
            else:
                prog = None
        except Exception as e:
            log_error(f"Kernel compile failed: {e}")
            return None

        if prog is None:
            log_error(f"[GPU]  Disabling {dev_name} after repeated build failure/hang")
            self.disabled = True
            self.context = None
            self.queue = None
            self.program = self.kernel_single = self.kernel_chain = self.kernel_bloom = self.kernel_verify = None
            return None

        self.program = prog
        self.kernel_single = prog.find_single_rules_gpu
        self.kernel_chain = prog.find_rule_chains_gpu
        self.kernel_bloom = prog.build_bloom_filter_gpu
        self.kernel_verify = prog.verify_pairs_gpu
        self._compiled_depth = current_depth
        self._program_cache[current_depth] = (prog, self.kernel_single, self.kernel_chain, self.kernel_bloom, self.kernel_verify)
        log_info("[GPU]  Kernel compiled successfully")
        return prog

    def _recreate_context(self):
        """Create a fresh OpenCL context/queue on the same device, abandoning
        a previous one that may still have a build stuck inside it. Clears
        buffer/kernel state tied to the old context since it's no longer
        valid to use."""
        try:
            self.context = cl.Context([self.device])
            self.queue = cl.CommandQueue(self.context)
            for buf in [self.bloom_buf, self._rules_buf, self._rules_offsets_buf, self._rules_lengths_buf]:
                if buf is not None:
                    try: buf.release()
                    except Exception: pass
            self.bloom_buf = self._rules_buf = self._rules_offsets_buf = self._rules_lengths_buf = None
            self._rules_buf_key = None
            self.gpu_rules = []
            self.rule_index = {}
            self.program = self.kernel_single = self.kernel_chain = self.kernel_bloom = self.kernel_verify = None
            self._program_cache = {}  # programs from the old context are invalid
            return True
        except Exception as e:
            log_error(f"[GPU]  Failed to create fresh context for retry: {e}")
            return False

    def _reset_gpu(self, error):
        log_warn(f"[GPU] Fatal kernel error: {error} — resetting context")
        # Release all buffers
        for buf in [self.bloom_buf, self._rules_buf, self._rules_offsets_buf, self._rules_lengths_buf]:
            if buf is not None:
                try: buf.release()
                except Exception: pass
        if self.queue is not None:
            try: self.queue.finish()
            except Exception: pass
        # Clear state
        self.bloom_buf = self._rules_buf = self._rules_offsets_buf = self._rules_lengths_buf = None
        self._rules_buf_key = None  # force re-upload of rules after reset
        self.program = self.kernel_single = self.kernel_chain = self.kernel_bloom = self.kernel_verify = None
        self._program_cache = {}  # programs from the old context are invalid
        self.context = None
        self.queue = None
        self.gpu_rules = []
        self.rule_index = {}
        self._rules_buf_key = None
        # Recreate — NVIDIA OpenCL on Windows needs ~1-2 s to exit TDR/error state
        for attempt in range(3):
            try:
                time.sleep(1.5)
                self.context = cl.Context([self.device])
                self.queue = cl.CommandQueue(self.context)
                if not self.compile_kernel(force=True):
                    return False
                if self._bloom_recovery_fn:
                    bf = self._bloom_recovery_fn()
                    self.upload_bloom_filter(bf)
                elif self.bloom_np is not None:
                    self.upload_bloom_filter(self.bloom_np)
                return True
            except Exception as exc:
                log_error(f"Reset failed (attempt {attempt+1}/3): {exc}")
                self.context = None
                self.queue = None
        return False

    def _safe_queue_finish(self):
        if self.queue is None: return False
        res = []
        def fin():
            try:
                self.queue.finish()
                res.append(True)
            except Exception:
                res.append(False)
        t = threading.Thread(target=fin, daemon=True); t.start()
        t.join(timeout=90)
        if t.is_alive(): return False
        return bool(res) and res[0]

    def _safe_build_program(self, src, timeout=180, build_options=None):
        """Build an OpenCL program on a watchdog thread so a driver-level
        compile hang (seen on some multi-GPU / laptop-hybrid setups) can't
        freeze the whole run forever. Mirrors _safe_queue_finish's pattern:
        if the build thread is still alive after `timeout` seconds, we give
        up on it (the thread is left as a daemon and abandoned — OpenCL
        offers no safe way to cancel an in-flight build) and return None so
        the caller can fail gracefully instead of hanging at "100%"."""
        prog = cl.Program(self.context, src)
        result = {}
        def do_build():
            try:
                prog.build(options=build_options or [])
                result['ok'] = True
            except Exception as e:
                result['ok'] = False
                result['err'] = e
        t = threading.Thread(target=do_build, daemon=True)
        t.start()
        t.join(timeout=timeout)
        if t.is_alive():
            raise _KernelBuildTimeout(f"build did not return within {timeout}s")
        if not result.get('ok'):
            raise result.get('err', RuntimeError("kernel build failed"))
        return prog

    def generate_bloom_filter(self, target_words):
        total_bytes = self.params['BLOOM_NUM_SHARDS'] * self.params['BLOOM_SHARD_BYTES']
        bf = np.zeros(total_bytes, dtype=np.uint8)
        log_info(f"[BLOOM] CPU build: {total_bytes//1024//1024}MB, {len(target_words):,} words, {self.params['BLOOM_NUM_SHARDS']} shard(s)")
        shard_bits = self.params['BLOOM_SHARD_BITS']
        shard_bytes = self.params['BLOOM_SHARD_BYTES']
        ns = self.params['BLOOM_NUM_SHARDS']
        ncols = shutil.get_terminal_size((80,24)).columns
        for w in tqdm(target_words, desc=green("  Bloom filter"), unit="word", ncols=ncols, leave=False,
                      bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}]"):
            wb = w.encode('latin-1')
            for s in range(ns):
                seed1 = (FNV1A_SEED1 + s) & 0xFFFFFFFF
                seed2 = (FNV1A_SEED2 + s) & 0xFFFFFFFF
                h1 = fnv1a_32(wb, seed1); h2 = fnv1a_32(wb, seed2)
                for i in range(BLOOM_HASH_FUNCTIONS):
                    idx = (h1 + i*h2) % shard_bits
                    byte_off = s*shard_bytes + (idx//8)
                    bf[byte_off] |= 1 << (idx%8)
        return bf

    def generate_bloom_filter_gpu(self, target_words):
        ns = self.params['BLOOM_NUM_SHARDS']
        shard_bytes = self.params['BLOOM_SHARD_BYTES']
        total_bytes = ns * shard_bytes
        nw = len(target_words)
        if not self.context or not self.program or not self.kernel_bloom:
            reason = ("no GPU context" if not self.context else
                      "kernel not compiled" if not self.program else
                      "bloom kernel missing after compile")
            log_warn(f"[BLOOM] GPU not ready ({reason}) — falling back to CPU build")
            return self.generate_bloom_filter(target_words)
        log_info(f"[BLOOM] GPU build: {total_bytes//1024//1024}MB, {nw} words, {ns} shards")
        mf = cl.mem_flags
        bufs = []
        try:
            wf, wo, wl = self._flatten(target_words)
            words_buf = cl.Buffer(self.context, mf.READ_ONLY|mf.COPY_HOST_PTR, hostbuf=wf)
            offsets_buf = cl.Buffer(self.context, mf.READ_ONLY|mf.COPY_HOST_PTR, hostbuf=wo)
            lengths_buf = cl.Buffer(self.context, mf.READ_ONLY|mf.COPY_HOST_PTR, hostbuf=wl)
            bufs.extend([words_buf, offsets_buf, lengths_buf])
            bf_int32_size = (total_bytes + 3)//4
            bf_init = np.zeros(bf_int32_size, dtype=np.int32)
            bf_buf = cl.Buffer(self.context, mf.READ_WRITE|mf.COPY_HOST_PTR, hostbuf=bf_init)
            bufs.append(bf_buf)  # register for cleanup on exception; removed below on success
            gs = ((nw + self.local_work_size - 1) // self.local_work_size) * self.local_work_size
            self.kernel_bloom.set_args(words_buf, offsets_buf, lengths_buf, np.int32(nw), bf_buf)
            cl.enqueue_nd_range_kernel(self.queue, self.kernel_bloom, (gs,), (self.local_work_size,))
            if not self._safe_queue_finish(): raise RuntimeError("queue finish timeout")
            # Verify the GPU actually wrote something non-trivial before trusting
            # this buffer. A bloom filter can legitimately have a very low fill
            # ratio (e.g. fill=0.001% on a large --bloom-mb with a small
            # wordlist), in which case the set bits are sparse and can easily
            # fall entirely outside a small sampled region — sampling only the
            # first few KB of a 256MB+ buffer produced false "all-zero"
            # positives and silently discarded valid GPU results every time.
            # Downloading the full buffer is a one-off cost (once per bloom
            # build, not per batch) and gives an exact answer instead of a
            # statistical guess.
            verify = np.empty(bf_int32_size, dtype=np.int32)
            cl.enqueue_copy(self.queue, verify, bf_buf)
            all_zero = np.count_nonzero(verify) == 0
            del verify
            if all_zero and nw > 0:
                log_warn("[BLOOM] GPU build all-zero -> fallback to CPU")
                raise RuntimeError("all-zero")
            if self.bloom_buf: self.bloom_buf.release()
            bufs.remove(bf_buf)  # hand ownership to self.bloom_buf; don't release in finally
            self.bloom_buf = bf_buf
            self.bloom_np = None
            self._bloom_recovery_fn = lambda: self.generate_bloom_filter(target_words)
            return _BLOOM_ALREADY_ON_GPU
        except Exception as exc:
            log_warn(f"[BLOOM] GPU build failed ({exc}) -> CPU")
            return self.generate_bloom_filter(target_words)
        finally:
            for b in bufs: b.release()

    def upload_bloom_filter(self, bf):
        if bf is _BLOOM_ALREADY_ON_GPU: return
        if self.bloom_buf: self.bloom_buf.release()
        self.bloom_np = bf
        self.bloom_buf = cl.Buffer(self.context, cl.mem_flags.READ_ONLY|cl.mem_flags.COPY_HOST_PTR, hostbuf=bf)

    def _flatten(self, items):
        if not items:
            return (np.array([], dtype=np.uint8), np.array([], dtype=np.int32), np.array([], dtype=np.int32))
        enc = [x.encode('latin-1') for x in items]
        flat = b''.join(enc)
        offs = [0]; lens = [len(enc[0])]
        for b in enc[1:]: offs.append(offs[-1]+lens[-1]); lens.append(len(b))
        return (np.frombuffer(flat, dtype=np.uint8), np.array(offs, dtype=np.int32), np.array(lens, dtype=np.int32))

    def prepare_batch_data(self, words, rules):
        wf,wo,wl = self._flatten(words)
        rf,ro,rl = self._flatten(rules)
        return dict(words_flat=wf, word_offsets=wo, word_lengths=wl,
                    rules_flat=rf, rule_offsets=ro, rule_lengths=rl,
                    num_words=len(words), num_rules=len(rules))

    def prepare_words_data(self, words):
        wf,wo,wl = self._flatten(words)
        return dict(words_flat=wf, word_offsets=wo, word_lengths=wl, num_words=len(words), num_rules=len(self.gpu_rules))

    def _get_rules_buffers(self, mf):
        # Use a tuple of rules as key — immune to Python id() reuse after list reassignment
        key = tuple(self.gpu_rules)
        if self._rules_buf_key != key:
            for attr in ('_rules_buf','_rules_offsets_buf','_rules_lengths_buf'):
                if getattr(self, attr): getattr(self, attr).release()
            rf,ro,rl = self._flatten(self.gpu_rules)
            self._rules_buf = cl.Buffer(self.context, mf.READ_ONLY|mf.COPY_HOST_PTR, hostbuf=rf)
            self._rules_offsets_buf = cl.Buffer(self.context, mf.READ_ONLY|mf.COPY_HOST_PTR, hostbuf=ro)
            self._rules_lengths_buf = cl.Buffer(self.context, mf.READ_ONLY|mf.COPY_HOST_PTR, hostbuf=rl)
            self._rules_buf_key = key
        return self._rules_buf, self._rules_offsets_buf, self._rules_lengths_buf

    def set_base_words(self, words):
        self._base_words_precomputed = self._flatten(words)

    def get_word_batch_data(self, start, end):
        if self._base_words_precomputed is None:
            raise RuntimeError("Base words not precomputed — call set_base_words() first")
        full_wf, full_wo, full_wl = self._base_words_precomputed
        if start >= end or start >= len(full_wo):
            return dict(words_flat=np.array([], dtype=np.uint8),
                        word_offsets=np.array([], dtype=np.int32),
                        word_lengths=np.array([], dtype=np.int32),
                        num_words=0, num_rules=len(self.gpu_rules))
        end = min(end, len(full_wo))
        base_off = int(full_wo[start])
        end_off = int(full_wo[end-1]) + int(full_wl[end-1])
        wf = full_wf[base_off:end_off]
        wo = full_wo[start:end] - base_off
        wl = full_wl[start:end]
        return dict(words_flat=wf, word_offsets=wo, word_lengths=wl,
                    num_words=end-start, num_rules=len(self.gpu_rules))

    def process_all_words_single_rule(self, base_words, rules, bloom_filter, _silent=False,
                                       _shared_combos=None, _shared_lock=None, _position=None,
                                       _label=None):
        self.upload_bloom_filter(bloom_filter)
        if not self.compile_kernel(): return Counter()
        # Refresh GPU rules list
        self.gpu_rules = HashcatRuleValidator.validate_rules_for_gpu(rules)
        self.rule_index = {r:i for i,r in enumerate(self.gpu_rules)}
        counter = Counter()
        bs = self.params['WORDS_PER_BATCH']
        ncols = shutil.get_terminal_size((80,24)).columns
        t0 = time.time(); words_done = 0; nr = len(self.gpu_rules)
        desc = f"  STAGE 1 [{_label}] " if _label else "  STAGE 1 "
        with tqdm(total=len(base_words), desc=green(desc), unit="word", ncols=ncols,
                  bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}",
                  disable=_silent, position=_position, leave=True) as pbar:
            for i in range(0, len(base_words), bs):
                if _kb.quit_requested: break
                batch = base_words[i:i+bs]
                if batch:
                    found = self._run_single_kernel(self.prepare_words_data(batch))
                    if found:
                        self._consecutive_errors = 0
                        counter.update(found)
                    elif self.queue is None:
                        self._consecutive_errors += 1
                        if self._consecutive_errors >= self._MAX_CONSECUTIVE_ERRORS: break
                    words_done += len(batch)
                    elapsed = time.time()-t0
                    delta = len(batch) * nr
                    if _shared_combos is not None and _shared_lock is not None:
                        with _shared_lock:
                            _shared_combos[0] += delta
                        combos_for_speed = _shared_combos[0]
                    else:
                        combos_for_speed = words_done * nr
                    spd = _fmt_speed(combos_for_speed / elapsed if elapsed>0 else 0)
                    pbar.set_postfix({"rules": cyan(str(len(counter))), "spd": green(spd)}, refresh=False)
                pbar.update(len(batch))
        log_info(f"[S1]    {bold(green(str(len(counter))))} unique rules passed bloom filter")
        return counter

    def _run_single_kernel(self, bd):
        if not self.context or not self.queue or not self.kernel_single:
            return []
        mf = cl.mem_flags; bufs = []
        try:
            def B(arr, f=mf.READ_ONLY):
                b = cl.Buffer(self.context, f|mf.COPY_HOST_PTR, hostbuf=arr); bufs.append(b); return b
            bb = B(bd['words_flat']); bbo = B(bd['word_offsets']); bbl = B(bd['word_lengths'])
            rb, rbo, rbl = self._get_rules_buffers(mf)
            outs = self.safe_output_buffer_size(bd['num_words'], bd['num_rules'])
            fo = cl.Buffer(self.context, mf.WRITE_ONLY, outs*MAX_CHAIN_STRING_LEN); bufs.append(fo)
            fc = cl.Buffer(self.context, mf.READ_WRITE, 4); bufs.append(fc)
            cl.enqueue_copy(self.queue, fc, np.array([0], dtype=np.int32))
            tot = bd['num_words'] * bd['num_rules']
            gs = ((tot+self.local_work_size-1)//self.local_work_size)*self.local_work_size
            self.kernel_single.set_args(bb, bbo, bbl, rb, rbo, rbl, self.bloom_buf,
                                        np.int32(bd['num_words']), np.int32(bd['num_rules']), fo, fc)
            cl.enqueue_nd_range_kernel(self.queue, self.kernel_single, (gs,), (self.local_work_size,))
            if not self._safe_queue_finish():
                self._reset_gpu(RuntimeError("queue.finish() timed out or failed"))
                return []
            cnt = np.zeros(1, dtype=np.int32); cl.enqueue_copy(self.queue, cnt, fc)
            n = min(cnt[0], outs); out = []
            if n>0:
                data = np.zeros(n*MAX_CHAIN_STRING_LEN, dtype=np.uint8)
                cl.enqueue_copy(self.queue, data, fo)
                for i in range(n):
                    r = bytes(data[i*MAX_CHAIN_STRING_LEN:(i+1)*MAX_CHAIN_STRING_LEN]).split(b'\0')[0].decode('latin-1', errors='ignore')
                    if r: out.append(r)
            return out
        except Exception as e:
            log_warn(f"Single kernel error: {e}")
            if not self._reset_gpu(e):
                log_error("GPU reset failed - aborting batch")
            return []
        finally:
            for b in bufs:
                try: b.release()
                except Exception: pass

    def _gen_random_chains(self, depth, count, valid, hot, existing, new_set):
        gen = set(); max_att = count * MAX_ATTEMPTS_MULTIPLIER
        hot_budget = int(count * HOT_RULE_RATIO) if hot else 0
        # Each pass targets an *absolute* size for gen, not a relative delta.
        # Original code used (count-hot_budget) as the cold target, meaning cold
        # pass exited immediately once len(gen) exceeded that threshold — which it
        # always did after the hot pass when HOT_RULE_RATIO >= 0.5.
        for target, use_hot in [(hot_budget, True), (count, False)]:
            att = 0
            while len(gen) < target and att < max_att:
                att += 1
                if use_hot and hot:
                    hp = random.randint(0, depth-1)
                    parts = [random.choice(hot) if i==hp else random.choice(valid) for i in range(depth)]
                else:
                    parts = [random.choice(valid) for _ in range(depth)]
                k = ' '.join(parts)
                if k not in existing and k not in gen and k not in new_set:
                    gen.add(k)
        return gen

    def build_numeric_seed_families(self, max_depth):
        digits = '0123456789'
        sbd = defaultdict(set)
        # A
        for depth in range(1, min(4, max_depth)+1):
            for combo in itertools.product(digits, repeat=depth):
                sbd[depth].add(' '.join(f'^{ch}' for ch in reversed(combo)))
        # B
        for depth in range(1, min(4, max_depth)+1):
            for combo in itertools.product(digits, repeat=depth):
                sbd[depth].add(' '.join(f'${ch}' for ch in combo))
        # C
        for depth in range(1, min(4, max_depth)+1):
            for ops in itertools.product(['^','$'], repeat=depth):
                for digs in itertools.product(digits, repeat=depth):
                    sbd[depth].add(' '.join(f'{o}{d}' for o,d in zip(ops,digs)))
        # D
        transform_ops = ['l','u','c','C','t','r','d','f','E','k','K','{','}','[',']']
        t_digit_ops = [f'^{d}' for d in digits] + [f'${d}' for d in digits] + ['[',']']
        for depth in range(2, min(4, max_depth)+1):
            for t_op in transform_ops:
                for ops in itertools.product(t_digit_ops, repeat=depth-1):
                    seed = f"{t_op} {' '.join(ops)}"
                    if HashcatRuleValidator.validate_rule_for_gpu(seed):
                        sbd[depth].add(seed)
        # E (dates)
        days = [f"{d:02d}" for d in range(1,32)]
        months = [f"{m:02d}" for m in range(1,13)]
        years2 = [f"{y:02d}" for y in range(60,100)] + [f"{y:02d}" for y in range(0,31)]
        years4 = [str(y) for y in range(1960,2031)]
        date4 = set(); date6 = set(); date8 = set()
        for d in days:
            for m in months:
                date4.add(d+m); date4.add(m+d)
        for y in years4: date4.add(y)
        for d in days:
            for m in months:
                for y in years2:
                    date6.add(d+m+y); date6.add(m+d+y)
        for d in days:
            for m in months:
                for y in years4:
                    date8.add(d+m+y); date8.add(m+d+y)
        for dset,bd in ((date4,4),(date6,6),(date8,8)):
            if bd>max_depth: continue
            for ds in dset:
                sbd[bd].add(' '.join(f'${c}' for c in ds))
                sbd[bd].add(' '.join(f'^{c}' for c in reversed(ds)))
        if max_depth>=5:
            for ds in date4:
                app = ' '.join(f'${c}' for c in ds)
                pre = ' '.join(f'^{c}' for c in reversed(ds))
                for t_op in transform_ops:
                    for chain in (f"{t_op} {app}", f"{t_op} {pre}"):
                        if HashcatRuleValidator.validate_rule_for_gpu(chain):
                            sbd[5].add(chain)
        bracket_ops = ['[',']']
        for dset,bd,br in ((date4,4,range(2,5)),(date6,6,range(1,3)),(date8,8,range(1,2))):
            for num_b in br:
                nd = bd+num_b
                if nd>max_depth: continue
                for brackets in itertools.product(bracket_ops, repeat=num_b):
                    bpfx = ' '.join(brackets)
                    for ds in dset:
                        app = ' '.join(f'${c}' for c in ds)
                        pre = ' '.join(f'^{c}' for c in reversed(ds))
                        for chain in (f"{bpfx} {app}", f"{bpfx} {pre}"):
                            if HashcatRuleValidator.validate_rule_for_gpu(chain):
                                sbd[nd].add(chain)
        # F
        for depth in range(1, min(3,max_depth)+1):
            for combo in itertools.product(SPECIAL_CHARS_TOP, repeat=depth):
                chain = ' '.join(f'${ch}' for ch in combo)
                if HashcatRuleValidator.validate_rule_for_gpu(chain): sbd[depth].add(chain)
        # G
        for depth in range(1, min(3,max_depth)+1):
            for combo in itertools.product(SPECIAL_CHARS_TOP, repeat=depth):
                chain = ' '.join(f'^{ch}' for ch in reversed(combo))
                if HashcatRuleValidator.validate_rule_for_gpu(chain): sbd[depth].add(chain)
        # H
        sp_ops_top = [f'${ch}' for ch in SPECIAL_CHARS_TOP] + [f'^{ch}' for ch in SPECIAL_CHARS_TOP]
        for depth in range(2, min(3,max_depth)+1):
            for t_op in transform_ops:
                for ops in itertools.product(sp_ops_top, repeat=depth-1):
                    seed = f"{t_op} {' '.join(ops)}"
                    if HashcatRuleValidator.validate_rule_for_gpu(seed): sbd[depth].add(seed)
        # I
        for depth in range(2, min(4,max_depth)+1):
            n_digits = depth-1
            for digit_combo in itertools.product(digits, repeat=n_digits):
                for sp in SPECIAL_CHARS_CORE:
                    app = ' '.join(f'${d}' for d in digit_combo) + f' ${sp}'
                    if HashcatRuleValidator.validate_rule_for_gpu(app): sbd[depth].add(app)
                    pre = f'^{sp} ' + ' '.join(f'^{d}' for d in reversed(digit_combo))
                    if HashcatRuleValidator.validate_rule_for_gpu(pre): sbd[depth].add(pre)
        # J
        for op in LEET_OPS:
            if HashcatRuleValidator.validate_rule_for_gpu(op): sbd[1].add(op)
        if max_depth>=2:
            leet_followup = [f'${d}' for d in digits] + [f'^{d}' for d in digits] + \
                            [f'${ch}' for ch in SPECIAL_CHARS_CORE] + [f'^{ch}' for ch in SPECIAL_CHARS_CORE]
            for leet_op in LEET_OPS:
                for follow in leet_followup:
                    chain = f"{leet_op} {follow}"
                    if HashcatRuleValidator.validate_rule_for_gpu(chain): sbd[2].add(chain)
            for l1 in LEET_OPS:
                for l2 in LEET_OPS:
                    if l1!=l2 and HashcatRuleValidator.validate_rule_for_gpu(f"{l1} {l2}"):
                        sbd[2].add(f"{l1} {l2}")
        # K
        if max_depth>=2:
            for t1 in transform_ops:
                for t2 in transform_ops:
                    chain = f"{t1} {t2}"
                    if HashcatRuleValidator.validate_rule_for_gpu(chain): sbd[2].add(chain)
        # L
        for depth in range(2, min(3,max_depth)+1):
            n_digits = depth-1
            for sp in SPECIAL_CHARS_CORE:
                for digit_combo in itertools.product(digits, repeat=n_digits):
                    app = f'${sp} ' + ' '.join(f'${d}' for d in digit_combo)
                    if HashcatRuleValidator.validate_rule_for_gpu(app): sbd[depth].add(app)
                    pre = ' '.join(f'^{d}' for d in digit_combo) + f' ^{sp}'
                    if HashcatRuleValidator.validate_rule_for_gpu(pre): sbd[depth].add(pre)
        # M
        if max_depth>=2:
            for leet_op in LEET_OPS:
                for t_op in transform_ops:
                    if HashcatRuleValidator.validate_rule_for_gpu(f"{leet_op} {t_op}"):
                        sbd[2].add(f"{leet_op} {t_op}")
                    if HashcatRuleValidator.validate_rule_for_gpu(f"{t_op} {leet_op}"):
                        sbd[2].add(f"{t_op} {leet_op}")
        return dict(sbd)

    def run_seed_extraction_pass(self, base_words, sbd, bloom_filter, phase1_rules, _silent=False,
                                  _position=None, _label=None):
        if self.bloom_buf is None: self.upload_bloom_filter(bloom_filter)
        if not self.program:
            if not self.compile_kernel(): return Counter()
        if not self.rule_index:
            self.gpu_rules = HashcatRuleValidator.validate_rules_for_gpu(phase1_rules)
            self.rule_index = {r:i for i,r in enumerate(self.gpu_rules)}
        multi = []
        for depth, chains in sorted(sbd.items()):
            if depth >= 2:
                multi.extend(chains)
        if not multi:
            log_info("[SEED]    No multi-depth seeds")
            return Counter()
        total = sum(len(v) for d,v in sbd.items() if d>=2)
        d_levels = sorted(d for d in sbd if d>=2)
        depth_range_str = (f"d{d_levels[0]}–d{d_levels[-1]}" if len(d_levels) > 1
                           else (f"d{d_levels[0]}" if d_levels else "none"))
        log_info(f"[SEED]    Numeric seed pass: {total:,} chains across {len(d_levels)} depth level(s) ({depth_range_str})")
        counter = self._run_chains_against_words(base_words, multi, "  SEED PASS ", _silent,
                                                   _position=_position, _label=_label)
        log_info(f"[SEED]    {bold(green(str(len(counter))))} unique seed chains passed bloom filter")
        return counter

    def generate_informed_chains(self, rules, single_found, max_depth, seed_chains=None, prebuilt_sbd=None):
        max_depth = min(max_depth, MAX_HASHCAT_CHAIN)
        valid = [r for r in rules if HashcatRuleValidator.validate_rule_for_gpu(r)]
        if not valid: return []
        found_s = set(single_found.keys()) if single_found else set()
        hot = [r for r in valid if r in found_s]
        chains = set(valid)
        if seed_chains:
            for sc in seed_chains:
                if sc.count(' ') >= 1: chains.add(sc)
        for depth in range(2, max_depth+1):
            budget = self.params.get(f'CHAIN_GEN_LIMIT_{depth}', 0)
            if budget <= 0: continue
            budget = min(budget, len(valid)**depth)
            new = self._gen_random_chains(depth, budget, valid, hot, chains, set())
            chains.update(new)
        return list(chains)

    def process_all_words_chain_rules(self, base_words, rules, max_depth, bloom_filter,
                                      single_counter, seed_chains=None, prebuilt_sbd=None, _silent=False,
                                      _position=None, _label=None):
        if self.bloom_buf is None: self.upload_bloom_filter(bloom_filter)
        if not self.program:
            if not self.compile_kernel(): return Counter()
        if not self.rule_index:
            self.rule_index = {r:i for i,r in enumerate(self.gpu_rules)}
        chains = self.generate_informed_chains(rules, single_counter, max_depth, seed_chains, prebuilt_sbd)
        if not chains: return Counter()
        counter = self._run_chains_against_words(base_words, chains, "  STAGE 2 ", _silent,
                                                   _position=_position, _label=_label)
        log_info(f"[S2]    {bold(green(str(len(counter))))} unique chain rules passed bloom filter")
        return counter

    def _run_chains_against_words(self, base_words, chains, desc="  CHAINS  ", _silent=False,
                                   _shared_combos=None, _shared_lock=None, _position=None,
                                   _label=None):
        """Shared inner loop: iterate chain batches x word sub-batches, collect matches.
        Uses the same pre-flattened word-batch fast path the original seed-extraction
        pass used (set_base_words/get_word_batch_data), avoiding repeated
        latin-1 re-encoding of base_words on every chain batch."""
        counter = Counter()
        cbs = self.params['CHAINS_PER_BATCH']
        wsb = self.params['WORD_SUB_BATCH']
        n_batches = (len(chains) + cbs - 1) // cbs
        ncols = shutil.get_terminal_size((80, 24)).columns
        t0 = time.time()
        total_combos = 0
        self.set_base_words(base_words)
        bar_desc = f"{desc}[{_label}] " if _label else desc
        with tqdm(total=n_batches, desc=green(bar_desc), unit="batch", ncols=ncols,
                  bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}",
                  disable=_silent, position=_position, leave=True) as pbar:
            for ci in range(0, len(chains), cbs):
                if _kb.quit_requested: break
                cb = chains[ci:ci + cbs]
                seqs, depths = self._compute_chain_seqs(cb)
                for wi in range(0, len(base_words), wsb):
                    end = min(wi + wsb, len(base_words))
                    bd = self.get_word_batch_data(wi, end)
                    if bd['num_words'] == 0: continue
                    found = self._run_chain_kernel(bd, cb, (seqs, depths))
                    if found is None:
                        self._consecutive_errors += 1
                        if self._consecutive_errors >= self._MAX_CONSECUTIVE_ERRORS:
                            log_error(f"Too many consecutive GPU errors, aborting {desc.strip()}")
                            break
                    elif found:
                        self._consecutive_errors = 0
                        counter.update(found)
                if self._consecutive_errors >= self._MAX_CONSECUTIVE_ERRORS: break
                delta = len(cb) * len(base_words)
                total_combos += delta
                if _shared_combos is not None and _shared_lock is not None:
                    with _shared_lock:
                        _shared_combos[0] += delta
                    combos_for_speed = _shared_combos[0]
                else:
                    combos_for_speed = total_combos
                elapsed = time.time() - t0
                spd = _fmt_speed(combos_for_speed / elapsed if elapsed > 0 else 0)
                pbar.set_postfix({"rules": cyan(str(len(counter))), "spd": green(spd)}, refresh=False)
                pbar.update(1)
        return counter

    def evaluate_chains_for_ga(self, chains):
        """Stage 3 (genetic) companion to _run_chains_against_words above. Runs the
        full chain-batch x word-sub-batch sweep for one engine's slice of chains
        against whatever base_words were already cached via set_base_words(), and
        returns {chain_str: set(global_word_index)} for that slice only.

        This is exposed as a single high-level call (rather than the parent
        driving get_word_batch_data/_run_chain_kernel/etc one RPC at a time) so
        that in multi-GPU mode a non-primary engine's ProcessEngineProxy only
        needs ONE round trip per generation instead of dozens — each of those
        would otherwise pickle numpy word/result arrays across the process
        boundary redundantly (worker -> parent -> worker) for no reason, since
        the parent never needed to see the intermediate word batch at all."""
        cbs = self.params.get('CHAINS_PER_BATCH', 2000)
        wsb = self.params.get('WORD_SUB_BATCH', 20000)
        n_words_total = len(self._base_words_precomputed[1]) if getattr(self, '_base_words_precomputed', None) else 0
        hit_words = defaultdict(set)
        for ci in range(0, len(chains), cbs):
            cb = chains[ci:ci+cbs]
            seqs, depths = self._compute_chain_seqs(cb)
            for wi in range(0, n_words_total, wsb):
                end = min(wi + wsb, n_words_total)
                bd = self.get_word_batch_data(wi, end)
                if bd['num_words'] == 0: continue
                found = self._run_chain_kernel(bd, cb, (seqs, depths), return_word_idx=True)
                if found:
                    for local_idx, rule_str in found:
                        hit_words[rule_str].add(wi + local_idx)
            self._safe_queue_finish()
        return dict(hit_words)

    def _compute_chain_seqs(self, chains):
        maxd = self.params['MAX_CHAIN_DEPTH']
        seqs = []
        depths = []
        truncated = 0
        for c in chains:
            parts = c.split()
            if len(parts) > maxd:
                truncated += 1
                parts = parts[:maxd]
            depths.append(len(parts))
            idxs = [self.rule_index.get(r, -1) for r in parts]
            while len(idxs) < maxd:
                idxs.append(-1)
            seqs.extend(idxs)
        if truncated:
            log_warn(f"[GPU] {truncated} chain(s) truncated to max depth {maxd}")
        return seqs, depths

    def _run_chain_kernel(self, words, chains, _precomputed=None, return_word_idx=False):
        # `words` may be either a raw list of word strings, or an already-flattened
        # batch dict as returned by get_word_batch_data()/prepare_words_data() —
        # accept both so callers can pre-flatten once (SEED PASS) and avoid re-flattening
        # every sub-batch, without silently corrupting the word count (that was the bug:
        # passing a dict straight to prepare_words_data() iterated over its *keys* as
        # if they were words, and len(dict) was used as the word count).
        if not self.context or not self.queue or not self.kernel_chain:
            return []
        if _precomputed is not None:
            seqs_np = np.array(_precomputed[0], dtype=np.int32)
            depths_np = np.array(_precomputed[1], dtype=np.int32)
        else:
            seqs, depths = self._compute_chain_seqs(chains)
            seqs_np = np.array(seqs, dtype=np.int32)
            depths_np = np.array(depths, dtype=np.int32)
        if isinstance(words, dict):
            bd = words
        else:
            bd = self.prepare_words_data(words)
        n_words = bd['num_words']
        if n_words == 0 or not chains:
            return []
        mf = cl.mem_flags; bufs = []
        try:
            def B(arr, f=mf.READ_ONLY):
                b = cl.Buffer(self.context, f|mf.COPY_HOST_PTR, hostbuf=arr); bufs.append(b); return b
            bb = B(bd['words_flat']); bbo = B(bd['word_offsets']); bbl = B(bd['word_lengths'])
            rb, rbo, rbl = self._get_rules_buffers(mf)
            csb = B(seqs_np); cdb = B(depths_np)
            outs = self.safe_output_buffer_size(n_words, len(chains))
            fo = cl.Buffer(self.context, mf.WRITE_ONLY, outs*MAX_CHAIN_STRING_LEN); bufs.append(fo)
            fc = cl.Buffer(self.context, mf.READ_WRITE, 4); bufs.append(fc)
            # foundw: parallel per-hit word-index buffer. Always allocated/passed since it's
            # now part of the compiled kernel's fixed signature; only decoded when the caller
            # (Stage 3 GA marginal-coverage fitness) actually needs per-word hit identity.
            fw = cl.Buffer(self.context, mf.WRITE_ONLY, outs*4); bufs.append(fw)
            cl.enqueue_copy(self.queue, fc, np.array([0], dtype=np.int32))
            tot = n_words*len(chains)
            gs = ((tot+self.local_work_size-1)//self.local_work_size)*self.local_work_size
            self.kernel_chain.set_args(bb, bbo, bbl, rb, rbo, rbl, csb, cdb, self.bloom_buf,
                                       np.int32(n_words), np.int32(len(chains)),
                                       np.int32(self.params['MAX_CHAIN_DEPTH']), fo, fc, fw)
            cl.enqueue_nd_range_kernel(self.queue, self.kernel_chain, (gs,), (self.local_work_size,))
            if not self._safe_queue_finish():
                self._reset_gpu(RuntimeError("queue.finish() timed out or failed"))
                return None
            cnt = np.zeros(1, dtype=np.int32); cl.enqueue_copy(self.queue, cnt, fc)
            n = min(cnt[0], outs)
            if n<=0:
                return []
            data = np.zeros(n*MAX_CHAIN_STRING_LEN, dtype=np.uint8)
            cl.enqueue_copy(self.queue, data, fo)
            if return_word_idx:
                widx = np.zeros(n, dtype=np.int32)
                cl.enqueue_copy(self.queue, widx, fw)
                out = []
                for i in range(n):
                    r = bytes(data[i*MAX_CHAIN_STRING_LEN:(i+1)*MAX_CHAIN_STRING_LEN]).split(b'\0')[0].decode('latin-1', errors='ignore')
                    if r: out.append((int(widx[i]), r))
                return out
            out = []
            for i in range(n):
                r = bytes(data[i*MAX_CHAIN_STRING_LEN:(i+1)*MAX_CHAIN_STRING_LEN]).split(b'\0')[0].decode('latin-1', errors='ignore')
                if r: out.append(r)
            return out
        except Exception as e:
            log_warn(f"Chain kernel error: {e}"); self._reset_gpu(e); return None
        finally:
            for b in bufs:
                try: b.release()
                except Exception: pass

    def verify_pairs_exact(self, base_words, selected_chains, pairs, batch_size=200000):
        """--exact-recovery: for a small set of (chain_idx, base_word_idx)
        pairs (chain_idx indexes into `selected_chains`, base_word_idx
        indexes into `base_words`), compute the ACTUAL mangled output string
        on GPU (same apply() as the bloom-gated kernels, just unconditional
        + no bloom) and return them aligned with `pairs`, so the caller can
        check each one against a real (non-bloom) set of target_words. Meant
        to be called only with the already-small selected ruleset x its
        recorded hits — NOT a full base_words x rules sweep."""
        if not self.compile_kernel() or not self.kernel_verify:
            return [None] * len(pairs)
        # Atomic-token universe for these chains only (not the full phase1
        # pool) — keeps _get_rules_buffers()/rule_index scoped to exactly
        # what's needed for this verification pass.
        atomic = sorted({tok for c in selected_chains for tok in c.split()})
        self.gpu_rules = atomic
        self.rule_index = {r: i for i, r in enumerate(atomic)}
        seqs, depths = self._compute_chain_seqs(selected_chains)
        mcd = self.params['MAX_CHAIN_DEPTH']
        seqs_np = np.array(seqs, dtype=np.int32)
        depths_np = np.array(depths, dtype=np.int32)
        bwf, bwo, bwl = self._flatten(base_words)
        results = [None] * len(pairs)
        mf = cl.mem_flags
        for start in range(0, len(pairs), batch_size):
            chunk = pairs[start:start + batch_size]
            npairs = len(chunk)
            if npairs == 0:
                continue
            pw = np.array([p[1] for p in chunk], dtype=np.int32)  # base_word idx
            pc = np.array([p[0] for p in chunk], dtype=np.int32)  # chain idx
            bufs = []
            try:
                def B(arr, f=mf.READ_ONLY):
                    b = cl.Buffer(self.context, f | mf.COPY_HOST_PTR, hostbuf=arr); bufs.append(b); return b
                bb = B(bwf); bbo = B(bwo); bbl = B(bwl)
                rb, rbo, rbl = self._get_rules_buffers(mf)
                csb = B(seqs_np); cdb = B(depths_np)
                pwb = B(pw); pcb = B(pc)
                out_buf = cl.Buffer(self.context, mf.WRITE_ONLY, npairs * MAX_OUTPUT_LEN); bufs.append(out_buf)
                out_len_buf = cl.Buffer(self.context, mf.WRITE_ONLY, npairs * 4); bufs.append(out_len_buf)
                gs = ((npairs + self.local_work_size - 1) // self.local_work_size) * self.local_work_size
                self.kernel_verify.set_args(bb, bbo, bbl, rb, rbo, rbl, csb, cdb, pwb, pcb,
                                             np.int32(npairs), np.int32(mcd), out_buf, out_len_buf)
                cl.enqueue_nd_range_kernel(self.queue, self.kernel_verify, (gs,), (self.local_work_size,))
                if not self._safe_queue_finish():
                    self._reset_gpu(RuntimeError("queue.finish() timed out or failed"))
                    continue
                lens = np.zeros(npairs, dtype=np.int32)
                cl.enqueue_copy(self.queue, lens, out_len_buf)
                data = np.zeros(npairs * MAX_OUTPUT_LEN, dtype=np.uint8)
                cl.enqueue_copy(self.queue, data, out_buf)
                for i in range(npairs):
                    ol = int(lens[i])
                    if ol <= 0:
                        results[start + i] = ''
                        continue
                    s = bytes(data[i * MAX_OUTPUT_LEN:i * MAX_OUTPUT_LEN + ol]).decode('latin-1', errors='ignore')
                    results[start + i] = s
            except Exception as e:
                log_warn(f"Verify kernel error: {e}")
                self._reset_gpu(e)
            finally:
                for b in bufs:
                    try: b.release()
                    except Exception: pass
        return results

    def ensure_rules_ready(self, phase1_rules):
        """Populate gpu_rules/rule_index on demand. Split out of the various
        call sites so it can also be invoked remotely as a single RPC by
        ProcessEngineProxy (a remote caller can't just poke .gpu_rules /
        .rule_index attributes and expect them to affect the real engine
        living in another process)."""
        if not self.rule_index:
            self.gpu_rules = HashcatRuleValidator.validate_rules_for_gpu(phase1_rules)
            self.rule_index = {r: i for i, r in enumerate(self.gpu_rules)}
        return True
