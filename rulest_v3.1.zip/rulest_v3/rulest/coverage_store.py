"""
Disk-backed, streaming storage for the rule -> distinct-target-word
coverage matrix produced by ``selection.evaluate_full_coverage`` and
consumed by ``selection.select_rules_by_marginal_coverage``.

Why this exists
----------------
A candidate pool can run from tens of thousands up to ~1.7M rules (see
README). Keeping ``{rule: np.ndarray[int32]}`` for every one of them as a
live Python dict for the whole run means:

  * one dict entry + one boxed numpy array object per rule (CPython/NumPy
    object overhead alone runs well over 100 bytes per entry before a
    single hit is counted), and
  * the *entire* matrix has to stay resident in RAM for the whole
    coverage-evaluation phase AND the whole greedy-selection phase back to
    back, even though at any given instant only a handful of rules are
    actually being read or written.

``CoverageStore`` replaces that in-memory dict with a small SQLite
database on disk — the same disk-backed pattern ``minimize.py`` already
uses for its signature table once a run gets too big to comfortably hold
in memory. Coverage rows are written in batches as
``evaluate_full_coverage`` streams through the GPU-evaluation loop (never
all held in RAM at once), and are read back either one rule at a time or
via a streaming SQL cursor by the greedy selector, so peak memory is
bounded by the batch size / the number of rules the CELF heap is actively
holding — not by the size of the full candidate pool or the target
wordlist.

``CoverageStore`` implements ``collections.abc.Mapping``, so any code that
treats ``coverage`` as ``{rule: np.ndarray}`` — including the plain
in-memory dict fixtures used by the unit tests — keeps working unchanged
whether it is handed a real dict or a ``CoverageStore``.
"""
import os
import sqlite3
import tempfile
from collections.abc import Mapping

import numpy as np

# Shared empty-hit sentinel (avoids allocating a fresh empty array per rule
# with zero coverage — there are often many of these in a large pool).
EMPTY_HITS = np.empty(0, dtype=np.int32)


class CoverageStore(Mapping):
    """Streaming, disk-backed map of ``rule -> np.ndarray[int32]`` (the
    distinct target-word ids recovered by that rule).

    Rows are appended in batches with :meth:`put_many` — streaming,
    append-only, never requiring the full matrix in memory — and can be
    read back either by key (:meth:`__getitem__`, one row at a time) or via
    a streaming cursor (:meth:`items`, :meth:`iter_candidates_with_hits`) so
    a consumer never needs to materialize the whole matrix in memory.

    Backed by a temporary SQLite file by default (auto-deleted on
    :meth:`close`); pass an explicit ``path`` to persist it instead.
    """

    def __init__(self, path=None):
        self._owns_file = path is None
        if path is None:
            fd, path = tempfile.mkstemp(suffix='.db', prefix='rulest_coverage_')
            os.close(fd)
        self._path = path
        self._conn = sqlite3.connect(path)
        self._conn.execute('PRAGMA journal_mode = WAL')
        self._conn.execute('PRAGMA synchronous = OFF')
        self._conn.execute('PRAGMA temp_store = MEMORY')
        self._conn.execute('PRAGMA cache_size = -131072')  # ~128MB page cache
        self._conn.execute(
            'CREATE TABLE IF NOT EXISTS coverage ('
            ' rule   TEXT PRIMARY KEY,'
            ' hits   BLOB NOT NULL,'   # raw int32 bytes; empty blob = no hits
            ' n_hits INTEGER NOT NULL,'
            ' depth  INTEGER NOT NULL'
            ')'
        )
        self._conn.execute('CREATE INDEX IF NOT EXISTS idx_coverage_nhits ON coverage(n_hits)')
        self._conn.commit()
        self._closed = False
        self._len_cache = None

    # -- streaming write path ----------------------------------------------
    def put_many(self, rows):
        """Append/replace a batch of ``(rule, np.ndarray[int32])`` rows.

        Called once per GPU-evaluation batch from
        ``evaluate_full_coverage`` — never with the whole candidate pool at
        once — so peak memory on the write path is bounded by the caller's
        batch size, not by the total number of candidates.
        """
        payload = [
            (
                rule,
                arr.astype(np.int32, copy=False).tobytes(),
                int(arr.size),
                max(1, len(rule.split())),
            )
            for rule, arr in rows
        ]
        if not payload:
            return
        self._conn.executemany(
            'INSERT OR REPLACE INTO coverage (rule, hits, n_hits, depth) VALUES (?,?,?,?)',
            payload,
        )
        self._conn.commit()
        self._len_cache = None

    def flush(self):
        self._conn.commit()

    # -- Mapping protocol ----------------------------------------------------
    def __getitem__(self, rule):
        row = self._conn.execute('SELECT hits FROM coverage WHERE rule = ?', (rule,)).fetchone()
        if row is None:
            raise KeyError(rule)
        blob = row[0]
        return np.frombuffer(blob, dtype=np.int32) if blob else EMPTY_HITS

    def __contains__(self, rule):
        return self._conn.execute('SELECT 1 FROM coverage WHERE rule = ?', (rule,)).fetchone() is not None

    def __iter__(self):
        cur = self._conn.execute('SELECT rule FROM coverage')
        for (rule,) in cur:
            yield rule

    def __len__(self):
        if self._len_cache is None:
            self._len_cache = self._conn.execute('SELECT COUNT(*) FROM coverage').fetchone()[0]
        return self._len_cache

    def items(self):
        """Stream ``(rule, hits)`` pairs via a SQL cursor rather than
        materializing the whole matrix in memory at once."""
        cur = self._conn.execute('SELECT rule, hits FROM coverage')
        for rule, blob in cur:
            yield rule, (np.frombuffer(blob, dtype=np.int32) if blob else EMPTY_HITS)

    # -- selection-specific streaming helpers --------------------------------
    def iter_candidates_with_hits(self):
        """Stream ``(rule, n_hits, depth)`` for every rule with >=1 hit.

        Used by ``select_rules_by_marginal_coverage`` to seed the CELF heap
        without pulling any hit array into memory until the specific rule
        is actually popped off the heap and needs to be applied or
        re-validated.
        """
        cur = self._conn.execute('SELECT rule, n_hits, depth FROM coverage WHERE n_hits > 0')
        yield from cur

    def count_with_hits(self):
        row = self._conn.execute('SELECT COUNT(*) FROM coverage WHERE n_hits > 0').fetchone()
        return row[0] if row else 0

    # -- lifecycle ------------------------------------------------------------
    def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            self._conn.close()
        finally:
            if self._owns_file:
                for suffix in ('', '-wal', '-shm'):
                    try:
                        os.unlink(self._path + suffix)
                    except OSError:
                        pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass


class InMemoryCoverageStore(dict):
    """Pure in-memory counterpart to :class:`CoverageStore`, used when the
    candidate pool is small enough (see ``SELECTION_DISK_THRESHOLD`` in
    common.py) that disk-backed streaming would only add SQLite point-
    lookup overhead without any real memory benefit.

    Subclassing ``dict`` gives ``__getitem__``/``__contains__``/``__iter__``/
    ``__len__``/``items()``/``get()`` for free, at plain-dict speed (no I/O
    at all). Only the streaming-specific helpers below are added, so
    ``evaluate_full_coverage`` and ``select_rules_by_marginal_coverage``
    never need to know or care which of the two store types they were
    handed — both expose the exact same interface.
    """

    def put_many(self, rows):
        for rule, arr in rows:
            self[rule] = arr

    def iter_candidates_with_hits(self):
        for rule, arr in self.items():
            n = len(arr)
            if n:
                yield rule, n, max(1, len(rule.split()))

    def count_with_hits(self):
        return sum(1 for arr in self.values() if len(arr))

    def close(self):
        pass
