## Changelog — rulest v3 (local-search + streaming refinements)

### Added

#### `--local-search` (post-CELF 1-swap improvement)
After greedy marginal-coverage selection, an optional local-search pass tries
to replace selected rules with non-selected candidates when the swap strictly
increases distinct target recovery.

| Flag | Default | Description |
|------|---------|-------------|
| `--local-search` | off | Enable 1-swap local search (requires `--select-mode greedy`) |
| `--local-search-swaps N` | `3000` | Max swap attempts |
| `--local-search-pool N` | `15000` | Size of the residual-candidate pool |

- Prefers replacing low exclusive-contribution rules first
- Candidate pool is pre-filtered by raw hit count, then ranked by true residual gain
- Works with both in-memory and disk-backed `CoverageStore`
- Banner / output headers report local-search status and accepted swap count

```bash
python3 run_rulest.py base.txt target.txt -o rules.txt \
    --select-mode greedy --select-budget 50000 --local-search
```

#### `rulest/coverage_store.py`
Coverage matrix storage extracted into its own module:
- `CoverageStore` — SQLite-backed, streaming map `rule → hit array`
- `InMemoryCoverageStore` — plain-dict path for smaller runs
- Shared `Mapping` interface (drop-in for callers / tests)

#### Streaming wordlist loader (`io_utils.load_wordlist`)
Reads wordlist files incrementally (`for line in f`) instead of
`f.read()` + `split()`, cutting peak memory during load from ~3–4× file size
to roughly the final list size.

### Changed

#### Coverage evaluation — longer rules no longer skipped
When `--max-depth` is low (e.g. 2), Stage S still generates deeper seed
rules (up to depth 9+). Previously those longer candidates were quietly
dropped during coverage evaluation.

Now coverage temporarily raises the engine depth to match the deepest
candidate in the pool (at least 9 when Stage S rules are present), scores
them, then restores the original depth. Result: greedy selection can keep
useful longer rules instead of throwing them away.

Log example:
```text
[COVERAGE] Widening engine chain depth 2 -> 9 to evaluate the deepest
           candidates in this pool instead of excluding them
```

#### Other

- `MINIMIZE_DISK_THRESHOLD`: `500_000` → `1_000_000`
- New `SELECTION_DISK_THRESHOLD = 1_000_000` — below this, coverage stays
  in-memory; above, streams to disk-backed `CoverageStore`
- SELECT banner now shows local-search status when `--select-mode greedy`
- **Top N rules summary** at end of run:
  - `--select-mode frequency` → ranked by GPU frequency (unchanged)
  - `--select-mode greedy` → ranked by greedy / local-search selection order
    (shows marginal gain + original GPU freq)
- README updated with local-search flags and example

### Tests

- 7 new unit tests for `local_search_improve` in `tests/test_selection.py`
  - empty / already-optimal / improving swap / size preservation /
    max-swaps budget / cost_alpha / plain-dict coverage
- Full suite: **177 passed**

### Files touched

| File | Change |
|------|--------|
| `rulest/selection.py` | +`local_search_improve()`; streaming coverage; keep deeper rules in coverage eval |
| `rulest/cli.py` | CLI flags, banner, wiring after CELF, top-N display by mode |
| `rulest/coverage_store.py` | **new** — extracted store implementations |
| `rulest/common.py` | `SELECTION_DISK_THRESHOLD`, raised minimize threshold |
| `rulest/io_utils.py` | streaming wordlist load |
| `tests/test_selection.py` | local-search unit tests |
| `README.md` | flags + usage example |
| `CHANGELOG.md` | this file |
