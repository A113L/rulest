# rulest v3 — Release Notes

**From single-file `rulest_v2.py` → modular package + smarter rule selection**

---

## What changed

### 1. Modular architecture
The original 210 kB single-file engine was split into a clean Python package:

| Module | Responsibility |
|--------|----------------|
| `rulest/state.py` | Runtime flags |
| `rulest/common.py` | Logging, colors, constants, rule validator, CPU applicator |
| `rulest/minimize.py` | Signature-based functional minimization |
| `rulest/token_strip.py` | Stage 0 (CPU exact-match) |
| `rulest/devices.py` | OpenCL device discovery & dynamic sizing |
| `rulest/kernel_source.py` | OpenCL C kernel template |
| `rulest/gpu_engine.py` | Single-GPU engine |
| `rulest/gpu_worker.py` | Process-isolated GPU worker |
| `rulest/multi_gpu.py` | Multi-GPU orchestration |
| `rulest/genetic.py` | Stage 3 genetic algorithm |
| `rulest/extractor.py` | Pipeline orchestrator |
| `rulest/selection.py` | **New** — coverage evaluation + CELF selection |
| `rulest/cli.py` | Argument parsing & main flow |
| `run_rulest.py` | Entry point |

Behavior of Stages 0–3 and frequency-based output remains identical to v2 when using the default selection mode.

### 2. New post-processing: Coverage Evaluation + Greedy Selection (CELF)

**Problem in v2**  
Rules were sorted purely by raw GPU hit count. High-frequency rules often recovered almost the same passwords, wasting budget on redundant rules.

**Solution in v3**
1. **Coverage Evaluation**  
   Every candidate rule is evaluated against the real target wordlist.  
   GPU bloom-filter hits are verified with an exact kernel, producing a clean map:  
   `rule → set of distinct target passwords it actually recovers`.

2. **Greedy Marginal Coverage (CELF)**  
   Rules are selected one-by-one by the largest *new* coverage they add (lazy greedy / Cost-Effective Lazy Forward).  
   This maximises the union of recovered passwords for any given budget size.

Result: more diverse and efficient rulesets for the same number of rules.

**Streaming, disk-backed coverage matrix**  
Both phases above are built around a streaming `CoverageStore`
(`rulest/coverage_store.py`) instead of one giant in-memory dict:

* `evaluate_full_coverage` writes each GPU-evaluation batch's results
  straight to a small SQLite-backed store and drops the Python-side
  references — the full `{rule: hits}` matrix is never assembled in RAM at
  once, so memory use during this phase is bounded by the batch size, not
  by the size of the candidate pool or the target wordlist.
* `select_rules_by_marginal_coverage` seeds its CELF heap by streaming
  `(rule, hit_count, depth)` from the store and only fetches a rule's
  actual hit array lazily, one rule at a time, right when the greedy loop
  needs to apply or re-validate it.

This lets both phases run on candidate pools and target wordlists that
would not fit comfortably in memory as a plain Python dict. `CoverageStore`
implements the standard `Mapping` interface, so it is a drop-in replacement
everywhere the old in-memory dict was used.

---

## New CLI parameters

```text
Rule Selection (post-processing)
  --select-mode {frequency,greedy}
                        frequency (default): sort by raw GPU hit count (v2 behaviour)
                        greedy: CELF marginal-coverage selection against the real TARGET
  --select-budget N     Max rules to keep when using greedy (0 = run to saturation)
  --select-budgets LIST Comma-separated budgets, e.g. "64,250,1500,10000,25000,50000,150000"
                        Emits extra files <output>.<budget>.txt cut from the same ordering
  --select-cost-alpha A gain(r) = new_recovery / depth(r)**A
                        0 = pure marginal coverage (default)
                        >0 favours shorter/cheaper chains
  --exact-recovery      Report exact distinct target-word recovery after greedy selection
  --local-search        After CELF, run 1-swap local search to replace rules and squeeze
                        extra recovery (only with --select-mode greedy)
  --local-search-swaps N  Max swap attempts (default 3000)
  --local-search-pool N Size of residual-candidate pool considered (default 15000)
Example
Bash# Classic v2 behaviour (default)
python3 run_rulest.py base.txt target.txt -o rules.txt

# Greedy selection, keep best 50k rules
python3 run_rulest.py base.txt target.txt -o rules.txt \
    --select-mode greedy --select-budget 50000

# Generate multiple budget sizes in one run
python3 run_rulest.py base.txt target.txt -o rules.txt \
    --select-mode greedy \
    --select-budgets 64,250,1500,10000,25000,50000,150000

# Greedy + local search to further maximise recovery
python3 run_rulest.py base.txt target.txt -o rules.txt \
    --select-mode greedy --select-budget 50000 --local-search

Install & Run
Bashpip install -r requirements.txt
python3 run_rulest.py --help
python3 run_rulest.py base_wordlist.txt target_wordlist.txt -o rules.txt
Requirements: numpy, pyopencl, tqdm (+ working OpenCL ICD for GPU use).

Tests
Unit tests are included under tests/ (pytest):
Bashpip install -r requirements-dev.txt
pytest

Compatibility

Default mode (--select-mode frequency) produces the same ordering and output format as rulest_v2.py.
All previous CLI flags are preserved.
Multi-GPU, genetic algorithm, token-strip and bloom options work exactly as in v2.
