"""
Post-processing — marginal-coverage rule SELECTION.

minimize_by_signature() (see minimize.py) answers "which rules are
functionally distinct?" — it says nothing about which of those distinct
rules are actually worth keeping for a given budget. Sorting by raw GPU
frequency (the historical default) picks rules that individually recover
the most target words, but says nothing about *overlap*: two high-frequency
rules can recover almost the same subset of the target list, in which case
keeping both wastes budget that a lower-frequency-but-orthogonal rule would
have spent better.

The functions below implement "select by marginal coverage, not by summed
score": build C(r) = {DISTINCT TARGET WORDS actually recovered by rule r}
against the real target wordlist, then run a lazy greedy (CELF) set-cover
selection over that universe. The GPU bloom-filter evaluation is used as a
fast prefilter, but every bloom-positive (rule, base_word) pair is resolved
through the exact verification kernel before it enters C(r). This makes the
CELF objective semantically match the reported target recovery and removes
bloom false positives from the optimization itself.

Streaming design
-----------------
Both post-processing phases below are built around a streaming coverage
store (see coverage_store.py) instead of accumulating one big in-memory
dict up front:

  * ``evaluate_full_coverage`` writes each GPU-evaluation batch's coverage
    rows straight to the store (``put_many``) and drops the Python-side
    references immediately after — the full ``{rule: np.ndarray}`` matrix
    is never assembled in RAM as a whole, so peak memory during this phase
    is bounded by ``batch_size``, not by the size of the candidate pool.
  * ``select_rules_by_marginal_coverage`` seeds its CELF heap by streaming
    ``(rule, n_hits, depth)`` straight from the store and only fetches a
    rule's actual hit array lazily, one rule at a time, right when the
    CELF loop pops it off the heap — never materializing the whole matrix.

Two store implementations share the exact same interface (see
coverage_store.py):

  * ``InMemoryCoverageStore`` — a thin dict subclass, used below
    ``SELECTION_DISK_THRESHOLD`` candidates. Zero I/O, same memory profile
    as v3's original plain-dict implementation, so small/medium runs pay no
    streaming overhead at all.
  * ``CoverageStore`` — SQLite-backed, used above the threshold, so the
    candidate pool no longer has to fit in RAM. Individual point lookups
    cost roughly one order of magnitude more than a dict lookup (single-
    digit microseconds, mostly served from SQLite's page cache rather than
    real disk I/O once warm) — negligible next to the GPU-bound coverage
    evaluation phase this follows, and the trade that makes very large
    candidate pools/target wordlists possible at all instead of exhausting
    memory.

Both store types are ``Mapping``-compatible, so the functions below also
work unmodified against a plain in-memory ``dict`` (this is what the unit
tests use directly) — the fast streaming-candidate path only activates when
the object handed in actually exposes the ``iter_candidates_with_hits`` /
``count_with_hits`` helpers (i.e. it's one of the two store types above, as
produced by ``evaluate_full_coverage`` in production).
"""
import time
import heapq
import shutil
import itertools

import numpy as np
from tqdm import tqdm

from .common import (
    log_info, log_warn, log_section, bold, green, cyan, _fmt_speed,
    SELECTION_DISK_THRESHOLD, _kb,
)
from .genetic import GeneticRuleEvolver
from .coverage_store import CoverageStore, InMemoryCoverageStore, EMPTY_HITS as _EMPTY_HITS


def evaluate_full_coverage(gpu_engine, base_words, target_words, rules, max_depth, batch_size=4000):
    """GPU-evaluate every candidate rule and stream back *target* coverage.

    Returns a streaming ``Mapping[str, np.ndarray[int32]]`` — an
    ``InMemoryCoverageStore`` (plain dict, zero overhead) when the candidate
    pool is at or below ``SELECTION_DISK_THRESHOLD``, otherwise a disk-backed
    ``CoverageStore`` — instead of always building one big in-memory dict.
    Each integer in a rule's array is an index into the UNIQUE
    ``target_words`` sequence, so a rule's coverage means "which distinct
    target words does this rule actually recover?" rather than "which base
    words happened to produce a bloom-filter hit?". Coverage rows are
    written to the store one GPU-evaluation batch at a time and never
    accumulated as a whole in memory, so this scales to arbitrarily large
    candidate pools / target wordlists once the disk-backed store kicks in —
    memory use is then bounded by ``batch_size``, not by ``len(rules)`` or
    ``len(target_words)``.

    The GPU bloom-filter kernel is still used as the cheap first-stage
    prefilter.  Every bloom-positive ``(rule, base_word)`` pair is then passed
    through ``verify_pairs_exact`` and its actual output is mapped back to a
    target-word id.  Bloom false positives are consequently excluded before
    CELF sees the coverage matrix.

    This extra verification is intentional: a set-cover objective is only
    semantically correct if its universe is the thing we actually want to
    maximize — distinct recovered target words.  Tracking base-word indices
    is only a proxy and can overvalue rules whose hits collapse onto the same
    target password.
    """
    log_section("SELECTION — GPU Coverage Evaluation")
    rule_list = [r for r in rules if r and r != ':']

    # Two independent GPU-side limits apply to a chain candidate, and only
    # one of them is a real hardware ceiling:
    #
    #  1. Token DEPTH (`params['MAX_CHAIN_DEPTH']`, aka `mcd`) is a *runtime*
    #     kernel argument — see find_rule_chains_gpu in kernel_source.py,
    #     where the per-chain loop is bounded by the `mcd` parameter, not by
    #     the `#define MAX_CHAIN_DEPTH` (that define is unused inside the
    #     kernel body). It is only a *host-side* Python choice, driven by
    #     whatever depth the pipeline last compiled for (Stage 2's
    #     --max-depth is frequently much smaller than what the seed pass or
    #     the genetic algorithm explored). It can be raised for this pass —
    #     same pattern extractor.py already uses when flipping between
    #     Stage S's `seed_pass_depth` and Stage 2's `user_max_depth`: bump
    #     params['MAX_CHAIN_DEPTH'], reassign gpu_engine.params (propagates
    #     to MultiGPUEngine/ProcessEngineProxy sub-engines), recompile
    #     (force=True). compile_kernel()'s per-depth program cache makes
    #     restoring the original depth afterward free.
    #
    #  2. Chain STRING length (`MAX_CHAIN_STRING_LEN`, 128 bytes) IS a real
    #     hard ceiling: `cb[MAX_CHAIN_STRING_LEN]` is a fixed per-thread
    #     private array in the compiled kernel (common.py notes raising it
    #     to 512 kills GPU occupancy). A candidate whose tokens + separating
    #     spaces don't fit in that buffer would still get silently
    #     truncated on the GPU side regardless of the depth limit, so those
    #     candidates are excluded up front (not the depth-limited ones).
    from .common import MAX_CHAIN_STRING_LEN, MAX_HASHCAT_CHAIN

    def _chain_char_len(r):
        toks = r.split()
        return sum(len(t) for t in toks) + max(0, len(toks) - 1)

    oversized_chars = {r for r in rule_list if _chain_char_len(r) > MAX_CHAIN_STRING_LEN - 2}
    if oversized_chars:
        rule_list = [r for r in rule_list if r not in oversized_chars]
        log_warn(
            f"[COVERAGE] Excluded {bold(str(len(oversized_chars)))} candidate(s) whose "
            f"combined rule text exceeds the {MAX_CHAIN_STRING_LEN}-byte GPU chain-string "
            f"buffer — this one really is a fixed per-thread buffer size and can't be "
            f"widened per run without hurting GPU occupancy for every other candidate."
        )

    needed_depth = max((len(r.split()) for r in rule_list), default=1)
    target_depth = min(max(max_depth, needed_depth), MAX_HASHCAT_CHAIN)
    engine_mcd = getattr(gpu_engine, 'params', {}).get('MAX_CHAIN_DEPTH') if hasattr(gpu_engine, 'params') else None

    _restore_depth = None
    if isinstance(engine_mcd, int) and engine_mcd > 0 and target_depth > engine_mcd:
        log_info(
            f"[COVERAGE] Widening engine chain depth {bold(str(engine_mcd))} -> "
            f"{bold(str(target_depth))} to evaluate the deepest candidates in this pool "
            f"instead of excluding them"
        )
        gpu_engine.params['MAX_CHAIN_DEPTH'] = target_depth
        gpu_engine.params = gpu_engine.params  # re-trigger the setter: propagates to
                                                # MultiGPUEngine sub-engines / process-
                                                # isolated GPU workers, not just this object
        if gpu_engine.compile_kernel(force=True):
            _restore_depth = engine_mcd
        else:
            log_warn("[COVERAGE] Recompile at widened depth failed — falling back to exclusion")
            gpu_engine.params['MAX_CHAIN_DEPTH'] = engine_mcd
            gpu_engine.params = gpu_engine.params
            gpu_engine.compile_kernel(force=True)

    effective_max_depth = gpu_engine.params.get('MAX_CHAIN_DEPTH', target_depth) \
        if hasattr(gpu_engine, 'params') else target_depth
    oversized = [r for r in rule_list if len(r.split()) > effective_max_depth]
    if oversized:
        rule_list = [r for r in rule_list if len(r.split()) <= effective_max_depth]
        log_warn(
            f"[COVERAGE] Excluded {bold(str(len(oversized)))} candidate(s) still longer "
            f"than {effective_max_depth} tokens even after widening — likely above "
            f"MAX_HASHCAT_CHAIN ({MAX_HASHCAT_CHAIN}), hashcat's own ceiling on a single "
            f"rule's function-chain length, so these wouldn't be usable hashcat rules anyway."
        )

    rule_list.sort(key=lambda r: len(r.split()))
    n = len(rule_list)
    use_disk = n > SELECTION_DISK_THRESHOLD
    log_info(f"[COVERAGE] Candidates   : {bold(str(n))}")
    log_info(f"[COVERAGE] Base words   : {bold(str(len(base_words)))}")
    log_info(f"[COVERAGE] Target words : {bold(str(len(target_words)))}")
    log_info(
        f"[COVERAGE] Storage      : "
        f"{bold('disk-backed SQLite' if use_disk else 'in-memory')} "
        f"(threshold {SELECTION_DISK_THRESHOLD:,} candidates)"
    )
    if n == 0 or not target_words or not base_words:
        if _restore_depth is not None:
            gpu_engine.params['MAX_CHAIN_DEPTH'] = _restore_depth
            gpu_engine.params = gpu_engine.params
            gpu_engine.compile_kernel(force=True)
        return CoverageStore() if use_disk else InMemoryCoverageStore()

    try:
        import resource
        def _rss_mb():
            return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    except ImportError:
        def _rss_mb():
            return -1.0

    # Preserve first-seen order while giving CELF a compact universe of
    # distinct target strings.  The caller's target list may contain duplicates.
    unique_targets = list(dict.fromkeys(target_words))
    target_to_id = {word: i for i, word in enumerate(unique_targets)}
    n_unique_targets = len(unique_targets)

    # A throwaway evolver is used only as the existing GPU-dispatch shim.
    evolver = GeneticRuleEvolver(
        gpu_engine, base_words, rule_pool=[], max_depth=max(2, max_depth)
    )
    evolver.active_words = base_words

    # Streaming sink: coverage rows are flushed via put_many() one
    # GPU-evaluation batch at a time instead of being accumulated as one big
    # Python dict up front. Below SELECTION_DISK_THRESHOLD candidates this is
    # an InMemoryCoverageStore (a plain dict — put_many() is just a dict
    # update, same cost and memory profile as v3's original implementation,
    # so small/medium runs pay zero streaming overhead). Above the
    # threshold it's a disk-backed CoverageStore, so the candidate pool no
    # longer has to fit in RAM at all. The only things kept resident across
    # the whole loop besides the store itself are these two small,
    # batch-count-sized accumulators used purely for the summary line below:
    #   - covered_any: running count of rules with >=1 hit
    #   - reached_mask: boolean union mask over the target-word universe
    #                   (size = n_unique_targets, independent of len(rules))
    try:
        store = CoverageStore() if use_disk else InMemoryCoverageStore()
        reached_mask = np.zeros(n_unique_targets, dtype=bool)
        covered_any = 0

        ncols = shutil.get_terminal_size((80, 24)).columns
        t0 = time.time()
        with tqdm(total=n, desc=green("  Coverage eval"), unit="rule", ncols=ncols,
                  bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}") as pbar:
            for i in range(0, n, batch_size):
                if _kb.poll():
                    log_warn("[COVERAGE] Early exit — keeping coverage collected so far")
                    break
                chunk = rule_list[i:i + batch_size]
                population = [tuple(r.split()) for r in chunk]

                # verify_pairs_exact() (below, previous iteration) narrows
                # gpu_engine.rule_index to whatever chains IT was last called
                # with. evaluate_population() needs rule_index to cover every
                # token in THIS batch, or unrecognized tokens silently resolve
                # to -1 and the GPU kernel reports a corrupted, truncated chain
                # string that doesn't match any key in hit_words (KeyError).
                # Rebuild it fresh for this batch before dispatching.
                gpu_engine.prepare_rule_pool(chunk)
                hit_words = evolver.evaluate_population(population)

                # The bloom kernel only tells us which base words produced a
                # probable hit.  Recompute those pairs with the exact verification
                # kernel so the coverage universe is target_words, not base_words.
                pairs = []
                for ci, tok in enumerate(population):
                    cs = ' '.join(tok)
                    hits = hit_words.get(cs)
                    if hits:
                        pairs.extend((ci, int(wi)) for wi in hits)

                exact_outputs = gpu_engine.verify_pairs_exact(
                    base_words, chunk, pairs, batch_size=batch_size
                ) if pairs else []

                per_rule_targets = [set() for _ in chunk]
                for (ci, _wi), output in zip(pairs, exact_outputs):
                    if output is None:
                        continue
                    target_id = target_to_id.get(output)
                    if target_id is not None:
                        per_rule_targets[ci].add(target_id)

                # Build this batch's rows, fold them into the running summary
                # accumulators, then stream them straight to disk and drop the
                # Python-side references before moving on to the next batch —
                # this is the actual streaming step: the coverage matrix never
                # accumulates in RAM across batches.
                batch_rows = []
                for r, ids in zip(chunk, per_rule_targets):
                    if ids:
                        arr = np.fromiter(sorted(ids), dtype=np.int32, count=len(ids))
                        covered_any += 1
                        reached_mask[arr] = True
                    else:
                        arr = _EMPTY_HITS
                    batch_rows.append((r, arr))
                store.put_many(batch_rows)

                # One-shot pass: do not let the GA hit cache grow with the entire
                # candidate pool.
                evolver._hit_cache.clear()
                pbar.update(len(chunk))
                elapsed = time.time() - t0
                spd = _fmt_speed(pbar.n / elapsed if elapsed > 0 else 0, "rules")
                avg_depth = sum(len(r.split()) for r in chunk) / len(chunk)
                pbar.set_postfix({"spd": green(spd), "depth": f"{avg_depth:.1f}",
                                   "rss": f"{_rss_mb():.0f}MB"}, refresh=False)

        total_recovered = int(reached_mask.sum())
        log_info(
            f"[COVERAGE] {green('Done')}  rules with >=1 exact target hit: "
            f"{bold(cyan(str(covered_any)))}/{n}; distinct targets reachable: "
            f"{bold(cyan(str(total_recovered)))}/{n_unique_targets}"
        )
        return store
    finally:
        _restore_engine_depth(gpu_engine, _restore_depth)


def _restore_engine_depth(gpu_engine, restore_depth):
    """Best-effort: put the engine's compiled chain depth back to whatever
    it was before evaluate_full_coverage widened it, so later pipeline
    stages (e.g. a subsequent --select-budgets pass, or any caller that
    keeps using this engine afterward) see the depth they expect rather
    than being left at whatever the largest coverage candidate needed.
    Failure here is logged, not raised — the coverage results already
    computed are unaffected either way."""
    if restore_depth is None:
        return
    try:
        gpu_engine.params['MAX_CHAIN_DEPTH'] = restore_depth
        gpu_engine.params = gpu_engine.params
        gpu_engine.compile_kernel(force=True)
    except Exception as e:
        log_warn(f"[COVERAGE] Could not restore engine depth to {restore_depth}: {e}")


def select_rules_by_marginal_coverage(coverage, counts, n_target_words, budget=None, cost_alpha=0.0):
    """Lazy greedy (CELF) submodular set-cover selection.

    Instead of ranking rules by their own score and summing:
        score(r1) + score(r2) + ... + score(rk)
    this maximizes the *union* actually recovered:
        | C(r1) u C(r2) u ... u C(rk) |
    by repeatedly picking the rule with the largest NEW recovery given what's
    already selected. Naive greedy is O(rules x budget); CELF exploits
    submodularity (marginal gains only ever shrink as the covered set grows)
    to lazily re-validate the heap top instead of rescanning every rule each
    step, which is what makes this tractable at 150k-1.7M candidate rules.

    `coverage`: rule -> np.ndarray(int32 word_idx), from
                evaluate_full_coverage(). In production this is a streaming
                CoverageStore (disk-backed); the unit tests pass a plain
                in-memory dict, which works identically since CoverageStore
                is a Mapping with the same interface.
    `counts`:   {rule: raw_gpu_frequency} — used only to break ties
                deterministically, never as the optimization objective.
    `n_target_words`: size of the boolean "covered" mask — number of
                unique target words. Coverage indices are target-word ids.
    `budget`:   max rules to select; None = run to saturation (stop once no
                remaining rule adds anything).
    `cost_alpha`: gain(r) = new_recovery(r) / depth(r)**cost_alpha. 0 = pure
                marginal-coverage greedy. >0 favors shorter/cheaper chains
                among rules with similar marginal gain.

    Streaming: the CELF heap is seeded from a stream of (rule, n_hits,
    depth) triples — either CoverageStore.iter_candidates_with_hits()'s SQL
    cursor in production, or a generator over coverage.items() for a plain
    dict — so the initial hit *counts* used as heap priorities never require
    pulling every rule's hit array into memory up front. A rule's actual
    np.ndarray of target ids is only ever fetched (via coverage[r]) lazily,
    one rule at a time, right when the CELF loop pops that rule off the heap
    to apply it or lazily re-validate its marginal gain. Peak memory is
    therefore bounded by the number of candidates-with-hits (small tuples
    only, no arrays) plus a single boolean covered_mask over target_words —
    not by the size of the full coverage matrix.

    Coverage sets are tracked as a single numpy boolean mask over target_words
    (updated in place with fancy indexing) rather than Python set unions —
    with 150k-1.7M candidates this avoids repeated hashing and boxed-int set
    churn, matching the same memory rationale as switching
    evaluate_full_coverage's storage from frozenset to int32 arrays.

    Returns (selected, covered_mask):
        selected     -> list of (rule, marginal_gain) in selection order (best first)
        covered_mask -> np.ndarray(bool), True at every target-word id
                        recovered by `selected`
    """
    def cost_for_depth(depth):
        if cost_alpha <= 0:
            return 1.0
        return max(1, depth) ** cost_alpha

    def cost(r):
        return cost_for_depth(len(r.split()))

    log_section("SELECTION — Greedy Marginal Coverage (CELF)")

    # Stream the candidates-with-hits straight from the store (or, for a
    # plain in-memory dict as used by the unit tests, from a generator over
    # .items()) rather than materializing a sorted list of every rule up
    # front. NOTE: `counts` intentionally has no bearing on final pop order
    # here — a binary heap always yields its global minimum tuple on pop()
    # regardless of the order elements were pushed in, so any pre-sort by
    # `counts` before pushing cannot change which rule comes out first; the
    # heap tuple (-gain, rule, stamp) is what actually decides ties (by
    # rule string). This mirrors v3's original tie-break behavior exactly —
    # `counts` is accepted and documented as a tie-breaker but was already
    # inert for that reason before this refactor, and is kept unchanged
    # here rather than "fixed" as part of a streaming-only rebuild.
    if hasattr(coverage, 'iter_candidates_with_hits'):
        candidates = coverage.iter_candidates_with_hits()
        n_candidates = coverage.count_with_hits()
    else:
        n_candidates = sum(1 for c in coverage.values() if len(c))
        candidates = (
            (r, len(c), max(1, len(r.split())))
            for r, c in coverage.items() if len(c)
        )

    limit = budget if budget else n_candidates
    log_info(f"[SELECT] Candidates (with >=1 hit) : {bold(str(n_candidates))}")
    log_info(f"[SELECT] Budget                    : {bold(str(limit) if budget else 'unbounded (saturation)')}")
    log_info(f"[SELECT] Cost alpha                : {bold(str(cost_alpha))}")

    heap = []
    for i, (r, n_hits, depth) in enumerate(candidates):
        # This can iterate well over a million candidates before the main
        # greedy loop below (which already polls) gets a chance to run, so
        # [p]/[r]/[q] would otherwise appear to hang during heap construction
        # on a large pool. Check every 50k rather than every iteration to
        # keep the lock/condition overhead negligible.
        if i % 50_000 == 0 and _kb.poll():
            log_warn("[SELECT] Early exit — heap construction interrupted")
            heap = []
            break
        heapq.heappush(heap, (-(n_hits / cost_for_depth(depth)), r, 0))

    selected = []
    covered_mask = np.zeros(n_target_words, dtype=bool)
    n_covered = 0
    stamp = 0
    ncols = shutil.get_terminal_size((80, 24)).columns
    with tqdm(total=limit, desc=green("  Greedy select"), unit="rule", ncols=ncols,
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}") as pbar:
        while heap and len(selected) < limit:
            if _kb.poll():
                log_warn("[SELECT] Early exit — keeping rules selected so far")
                break
            neg_gain, r, s = heapq.heappop(heap)
            if s == stamp:
                gain = -neg_gain
                if gain <= 0:
                    break  # saturation: nothing left adds any new coverage
                selected.append((r, gain))
                covered_mask[coverage[r]] = True
                n_covered = int(covered_mask.sum())
                stamp += 1
                pbar.update(1)
                pbar.set_postfix({"recovered": cyan(str(n_covered))}, refresh=False)
                continue
            c = coverage[r]
            new_gain = int(np.count_nonzero(~covered_mask[c])) / cost(r)
            if new_gain <= 0:
                continue
            heapq.heappush(heap, (-new_gain, r, stamp))

    log_info(f"[SELECT] {green('Done')}  rules selected: {bold(cyan(str(len(selected))))}  "
              f"recovered: {bold(cyan(str(n_covered)))}")
    return selected, covered_mask


def compute_exact_recovery(target_words, selected, coverage):
    """Return exact recovery from the target-word coverage matrix.

    ``evaluate_full_coverage`` now resolves every bloom-positive pair through
    the exact GPU verification kernel before building ``coverage``.  Therefore
    the coverage matrix is already zero-FPR and directly represents distinct
    target-word ids.  No second GPU pass is necessary here; this function is
    kept as the explicit reporting hook used by ``--exact-recovery``.

    Returns ``(n_exact_covered, recovery_pct, matched_target_strings)``.
    """
    log_section("SELECTION — Exact Recovery (--exact-recovery)")
    unique_targets = list(dict.fromkeys(target_words))
    if not selected or not unique_targets:
        log_info("[EXACT] No selected rules or target words — nothing to verify")
        return 0, 0.0, set()

    target_ids = set()
    for rule, _gain in selected:
        hits = coverage.get(rule)
        if hits is not None and len(hits):
            target_ids.update(int(i) for i in hits)

    matched = {unique_targets[i] for i in target_ids if 0 <= i < len(unique_targets)}
    recovery_pct = len(matched) / len(unique_targets)
    log_info(
        f"[EXACT] {green('Done')}  distinct target_words cracked: "
        f"{bold(cyan(str(len(matched))))}/{len(unique_targets)} ({recovery_pct:.2%})"
    )
    return len(matched), recovery_pct, matched



def local_search_improve(
    selected,
    coverage,
    n_target_words,
    max_swaps=3000,
    pool_size=15000,
    cost_alpha=0.0,
    refresh_passes=3,
):
    """1-swap local search to further maximize target recovery after CELF.

    Greedy (CELF) is already near-optimal for monotone submodular maximization,
    but a modest number of improving swaps can still recover a few extra
    distinct target words, especially when the budget is tight or when
    cost_alpha biased the ordering toward shorter chains.

    Algorithm
    ---------
    1. Build cover_count[target] = how many selected rules cover each target.
    2. Stream non-selected candidates once; keep a larger pre-filtered set
       (by raw hit count) with hit arrays cached in memory, then rank a
       ``pool_size`` shortlist by residual gain against the *current*
       covered set. Because the hit arrays for the whole pre-filtered set
       stay cached, this ranking is cheaply recomputed ("refreshed") from
       memory alone — no further disk/store lookups — every time a full
       pass over the selected set finishes with swap budget still left.
       This matters: a candidate that looked useless against the ORIGINAL
       greedy coverage (residual == 0, so excluded from the first pool) can
       become genuinely useful once an earlier swap in this same run frees
       up some of the targets it covers — without a refresh those
       candidates are invisible for the rest of the run.
    3. Repeatedly try swaps: remove one selected rule, add one pool candidate.
       Accept the swap if it strictly increases total distinct coverage, OR
       — when cost_alpha > 0 — if it keeps coverage identical while
       strictly reducing cost (a pure efficiency win the raw-coverage-only
       test below would otherwise silently pass over). Prefer replacing
       rules that have low exclusive contribution.
    4. Stop after ``max_swaps`` attempts total, or once ``refresh_passes``
       consecutive full passes (each followed by a pool refresh) produce no
       further improvement.

    Memory: only the selected set + the pre-filtered candidate pool (rules +
    their hit arrays) + the cover_count vector are resident. The full
    coverage matrix is never loaded.

    Returns
    -------
    selected : list[(rule, gain)]
        Possibly improved selection (same length as input when budget-limited),
        re-sorted by each rule's FINAL exclusive contribution to the covered
        set (descending). Unlike CELF's own selection order — where position
        i is meaningful because it reflects the i-th best marginal gain given
        the first i-1 picks — swaps happen in place at arbitrary positions,
        so returning them in original order would make position no longer
        correspond to value. Re-sorting restores a meaningful ordering, in
        particular so that a caller cutting this list into smaller budget
        prefixes (e.g. --select-budgets) still gets the most valuable rules
        first rather than whichever index slots happened not to get swapped.
        ``gain`` is each rule's final exclusive contribution (not its
        original CELF marginal gain, which is no longer a meaningful
        concept once swaps have happened).
    covered_mask : np.ndarray[bool]
        Final coverage mask after local search.
    n_improved : int
        Number of successful swaps performed.
    """
    if not selected or n_target_words == 0:
        return selected, np.zeros(n_target_words, dtype=bool), 0

    log_section("SELECTION — Local Search (1-swap improvement)")
    selected_rules = [r for r, _ in selected]
    selected_set = set(selected_rules)
    n_sel = len(selected_rules)

    # Multiplicity counts so we can evaluate swaps without rebuilding masks.
    cover_count = np.zeros(n_target_words, dtype=np.int32)
    hits_cache = {}  # rule -> ndarray, for selected rules + every pre-filtered candidate
    for r in selected_rules:
        h = coverage[r]
        hits_cache[r] = h
        if len(h):
            cover_count[h] += 1
    original_covered = int(np.count_nonzero(cover_count > 0))
    current_covered = original_covered
    log_info(f"[LS] Starting recovery     : {bold(cyan(str(current_covered)))}/{n_target_words}")
    log_info(f"[LS] Selected rules        : {bold(str(n_sel))}")
    log_info(f"[LS] Max swap attempts     : {bold(str(max_swaps))}")
    log_info(f"[LS] Candidate pool size   : {bold(str(pool_size))}")

    def cost_of(rule):
        depth = max(1, len(rule.split()))
        if cost_alpha <= 0:
            return 1.0
        return float(depth ** cost_alpha)

    # --- Pre-filter candidates once (streaming, never the full matrix) ---
    # This is the only pass over the whole candidate pool this function ever
    # makes. Everything after this works off `pre_pool_rules`/`hits_cache`,
    # already resident in memory, so pool refreshes below are essentially
    # free (pure numpy ops, no re-streaming from the coverage store).
    pre_pool_rules = []  # rule strings, cheap pre-filter by raw hit count / cost
    pre_limit = max(pool_size * 4, pool_size)
    if hasattr(coverage, 'iter_candidates_with_hits'):
        stream = coverage.iter_candidates_with_hits()
    else:
        stream = (
            (r, len(c), max(1, len(r.split())))
            for r, c in coverage.items() if len(c)
        )

    prelim = []  # (n_hits / cost, rule)
    for r, n_hits, depth in stream:
        if r in selected_set or n_hits <= 0:
            continue
        prelim.append((n_hits / cost_of(r), r))
    prelim.sort(key=lambda t: -t[0])
    if len(prelim) > pre_limit:
        prelim = prelim[:pre_limit]

    for _, r in prelim:
        h = coverage[r]
        if len(h):
            hits_cache[r] = h
            pre_pool_rules.append(r)

    # A pure "net residual > 0" pool can never surface a candidate that
    # duplicates coverage already achieved by a selected rule but does so
    # more cheaply (fewer/shorter tokens) — such a candidate always has
    # residual == 0 by construction, so it would be filtered out before the
    # swap loop ever got to compare costs. When cost_alpha > 0 the whole
    # point of that parameter is to prefer cheaper rules, so this is exactly
    # the class of swap it should be able to find (identical coverage, lower
    # cost) — hence a second, smaller pool kept separately for that case.
    eff_pool_size = max(1, pool_size // 4) if cost_alpha > 0 else 0

    def build_pool():
        """Rank the pre-filtered candidates by residual gain against the
        CURRENT cover_count (pure in-memory recompute, no store lookups).
        Returns (pool, eff_pool): `pool` is real coverage-adding candidates
        (residual > 0), ranked by cost-adjusted residual descending.
        `eff_pool` (only built when cost_alpha > 0) is zero-residual
        candidates — i.e. ones whose coverage is already fully subsumed by
        the current selection — ranked by cost ascending, so a selected
        rule can still be swapped for a strictly cheaper equivalent even
        though doing so changes total coverage by exactly zero."""
        ranked = []
        eff_ranked = []
        for r in pre_pool_rules:
            if r in selected_set:
                continue
            h = hits_cache[r]
            residual = int(np.count_nonzero(cover_count[h] == 0))
            if residual > 0:
                ranked.append((residual / cost_of(r), residual, r, h))
            elif eff_pool_size:
                eff_ranked.append((cost_of(r), r, h))
        ranked.sort(key=lambda t: -t[0])
        eff_ranked.sort(key=lambda t: t[0])
        return ranked[:pool_size], eff_ranked[:eff_pool_size]

    pool, eff_pool = build_pool()
    log_info(f"[LS] Promising candidates  : {bold(str(len(pool)))} (residual > 0)")
    if cost_alpha > 0:
        log_info(f"[LS] Efficiency candidates : {bold(str(len(eff_pool)))} "
                  f"(same coverage, lower cost — only tried when cost_alpha > 0)")

    if not pool and not eff_pool:
        log_info(f"[LS] {green('No improving candidates')} — local search has nothing to do")
        covered_mask = cover_count > 0
        return selected, covered_mask, 0

    def exclusive_count(rule):
        h = hits_cache.get(rule)
        if h is None or not len(h):
            return 0
        return int(np.count_nonzero(cover_count[h] == 1))

    n_improved = 0
    attempts = 0
    stale_passes = 0  # consecutive refreshed passes with zero accepted swaps

    ncols = shutil.get_terminal_size((80, 24)).columns
    pbar = tqdm(total=max_swaps, desc=green("  Local search"), unit="try", ncols=ncols,
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}")

    while attempts < max_swaps and stale_passes < max(1, refresh_passes):
        if _kb.poll():
            log_warn("[LS] Early exit — keeping swaps applied so far")
            break
        improved_this_pass = False
        # Re-sort selected by current exclusive contribution (kick out least unique first)
        sel_order = sorted(range(n_sel), key=lambda i: exclusive_count(selected_rules[i]))

        for si in sel_order:
            if attempts >= max_swaps:
                break
            s = selected_rules[si]
            hits_s = hits_cache[s]
            cost_s = cost_of(s)

            # Candidates that can add real coverage are tried first; only if
            # none of them work do we fall back to pure-efficiency swaps
            # (same coverage, lower cost — see build_pool()'s docstring).
            eff_candidates = (
                [(cost_c, c, h) for cost_c, c, h in eff_pool if cost_c < cost_s]
                if cost_alpha > 0 else []
            )
            candidate_iter = itertools.chain(
                ((c, hits_c) for _, _, c, hits_c in pool),
                ((c, h) for _, c, h in eff_candidates),
            )
            swapped = False
            for c, hits_c in candidate_iter:
                if attempts >= max_swaps:
                    break
                if c in selected_set:
                    continue
                attempts += 1
                pbar.update(1)

                # Simulate remove s
                lost = 0
                for idx in hits_s:
                    cover_count[idx] -= 1
                    if cover_count[idx] == 0:
                        lost += 1
                # Simulate add c
                gained = 0
                for idx in hits_c:
                    if cover_count[idx] == 0:
                        gained += 1
                    cover_count[idx] += 1

                net = gained - lost
                # Primary criterion: strictly more distinct coverage.
                # Secondary (only when cost_alpha biases toward shorter
                # chains): identical coverage delivered by a strictly
                # cheaper/shorter rule — a real efficiency win that `net`
                # alone can't see, since `net` only counts targets, not cost.
                # (cost_of(c) < cost_s is already guaranteed for anything
                # drawn from eff_candidates, so this also correctly accepts
                # net > 0 swaps found there, not just net == 0 ones.)
                accept = net > 0 or (net == 0 and cost_alpha > 0 and cost_of(c) < cost_s)
                if accept:
                    selected_rules[si] = c
                    selected_set.discard(s)
                    selected_set.add(c)
                    current_covered += net
                    n_improved += 1
                    improved_this_pass = True
                    swapped = True
                    pbar.set_postfix({
                        "recovered": cyan(str(current_covered)),
                        "swaps": str(n_improved),
                    }, refresh=False)
                    break  # next selected rule
                else:
                    # Rollback
                    for idx in hits_c:
                        cover_count[idx] -= 1
                    for idx in hits_s:
                        cover_count[idx] += 1

        if improved_this_pass:
            stale_passes = 0
            # Cover_count moved during this pass, which can make candidates
            # that were filtered out (residual == 0 at the last refresh)
            # newly useful, and stale ones no longer useful — rebuild the
            # ranked shortlist from the still-cached hit arrays so the next
            # pass actually sees them, instead of local search plateauing
            # early just because the pool snapshot went stale.
            pool, eff_pool = build_pool()
            if not pool and not eff_pool:
                break
        else:
            stale_passes += 1

    pbar.close()

    # Re-rank the final selection by each rule's exclusive contribution to
    # the FINAL covered set (see docstring: position no longer tracks value
    # after in-place swaps, so restore a meaningful order rather than
    # returning CELF's now-stale original ordering).
    final_order = sorted(
        selected_rules,
        key=lambda r: (-exclusive_count(r), cost_of(r), r),
    )
    new_selected = [(r, float(exclusive_count(r))) for r in final_order]
    covered_mask = cover_count > 0
    final_covered = int(covered_mask.sum())

    delta = final_covered - original_covered
    log_info(
        f"[LS] {green('Done')}  swaps accepted: {bold(cyan(str(n_improved)))}  "
        f"attempts: {attempts}  "
        f"recovered: {bold(cyan(str(final_covered)))}/{n_target_words} "
        f"({delta:+d} vs greedy)"
    )
    return new_selected, covered_mask, n_improved
