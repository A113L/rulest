## Changelog — rulest v3.1a (performance tuning + pause/resume hardening)

This release is a performance and reliability pass: no new flags, no change
to output rules — same results, achieved with less redundant work,
particularly on large candidate pools and long `--genetic` runs.

### Performance

- **Memoized the per-token rule application (`_py_apply_single_rule`) via
  `functools.lru_cache`.** This function sits on the hot path of signature
  hashing (minimization and GA fitness both re-apply the same handful of
  atomic tokens against the same probe words across millions of
  candidates); caching avoids re-deriving identical results.
- **Stabilized `active_words` subsampling in Stage 3.** The per-generation
  phase offset was being re-rolled every generation, producing a new list
  object each time. Since `_hit_cache` keys on `id(active_words)`, this
  silently invalidated the cross-generation cache every round — elites were
  being re-evaluated on GPU instead of served from cache — and forced a
  fresh pickled wordlist upload to every worker process each generation in
  multi-GPU mode. The offset is now re-rolled once per `full_sweep_every`
  block instead.
- **Eliminated a duplicate fitness evaluation per individual per
  generation** in the GA loop — `_base_fit()` was being called twice (once
  for the raw fitness ranking, once inside the fitness-sharing
  computation); the result is now computed once and reused for both.
- **Parallelized the disk-backed minimization path** (`_minimize_disk`,
  used above `MINIMIZE_DISK_THRESHOLD` candidates) with a worker pool for
  signature computation, matching the pattern already used by the
  in-memory path — the SQLite `executemany` batching stays on the main
  thread since that part is inherently serial.
- **Switched signature hashing from SHA-1 to BLAKE2b.** Grouping only
  needs collision resistance for equivalence-class bucketing, not
  cryptographic strength, and BLAKE2b is meaningfully faster on short
  inputs.
- **Replaced tuple-based rule-buffer cache keys with a version counter** on
  the GPU engine. Rebuilding and comparing a `tuple()` of the full rule
  list on every kernel launch added avoidable CPU overhead; a cheap
  `(version, length)` key achieves the same cache-invalidation semantics.
- **Added a small LRU cache in front of `CoverageStore.__getitem__`**,
  since the CELF selection loop can re-query the same rule's coverage
  multiple times as it re-validates stale heap entries; this trades a
  handful of SQLite round trips for dict lookups.
- **Removed redundant work in the GPU chain-verification path**: skip
  rebuilding `rule_index` in `verify_pairs_exact()` when the caller already
  populated it for the same chain batch via `prepare_rule_pool()`, and
  dropped one redundant `queue.finish()` call in `evaluate_chains_for_ga()`
  that duplicated synchronization already done inside `_run_chain_kernel()`.
- Minor housekeeping: `str.isascii()` instead of a manual codepoint scan,
  and removal of an unreferenced (dead) method.

### Reliability — pause/resume

- **Closed a gap where `[p]`/`[q]` had no interrupt point.** Heap
  construction in `select_rules_by_marginal_coverage()` (CELF
  initialization) iterated the full candidate list with no responsiveness
  check, so on very large pools (into the millions) pause/quit could
  appear to hang until the loop finished. It now polls periodically during
  construction.
- **Extended pause/quit coverage to the newly parallelized
  `_minimize_disk` path**, so the multiprocessing branch introduced above
  honors early exit exactly like the serial branch it replaced.
- Audited pause/quit propagation across every stage boundary (Stage 0/S0,
  S1, Seed, S2, S3, minimize, coverage evaluation, CELF, local search) —
  confirmed all are wired correctly end to end; the two items above were
  the only gaps found.


## Changelog — rulest v3.1 (local-search + streaming refinements)

### Added

#### `--local-search` (post-CELF 1-swap improvement)
After greedy marginal-coverage selection, an optional local-search pass tries
to replace selected rules with non-selected candidates when the swap strictly
increases distinct target recovery.

| Flag | Default | Description |
|------|---------|-------------|
| `--local-search` | off | Enable 1-swap local search (requires `--select-mode greedy`) |
| `--local-search-swaps N` | `3000` | Max swap attempts |
| `--local-search-pool N` | `15000` | Size of the residual-candidate pool |

- Prefers replacing low exclusive-contribution rules first
- Candidate pool is pre-filtered by raw hit count, then ranked by true residual gain
- Works with both in-memory and disk-backed `CoverageStore`
- Banner / output headers report local-search status and accepted swap count

```bash
python3 run_rulest.py base.txt target.txt -o rules.txt \
    --select-mode greedy --select-budget 50000 --local-search
```

#### `rulest/coverage_store.py`
Coverage matrix storage extracted into its own module:
- `CoverageStore` — SQLite-backed, streaming map `rule → hit array`
- `InMemoryCoverageStore` — plain-dict path for smaller runs
- Shared `Mapping` interface (drop-in for callers / tests)

#### Streaming wordlist loader (`io_utils.load_wordlist`)
Reads wordlist files incrementally (`for line in f`) instead of
`f.read()` + `split()`, cutting peak memory during load from ~3–4× file size
to roughly the final list size.

### Changed

#### Coverage evaluation — longer rules no longer skipped
When `--max-depth` is low (e.g. 2), Stage S still generates deeper seed
rules (up to depth 9+). Previously those longer candidates were quietly
dropped during coverage evaluation.

Now coverage temporarily raises the engine depth to match the deepest
candidate in the pool (at least 9 when Stage S rules are present), scores
them, then restores the original depth. Result: greedy selection can keep
useful longer rules instead of throwing them away.

Log example:
```text
[COVERAGE] Widening engine chain depth 2 -> 9 to evaluate the deepest
           candidates in this pool instead of excluding them
```

#### Other

- `MINIMIZE_DISK_THRESHOLD`: `500_000` → `1_000_000`
- New `SELECTION_DISK_THRESHOLD = 1_000_000` — below this, coverage stays
  in-memory; above, streams to disk-backed `CoverageStore`
- SELECT banner now shows local-search status when `--select-mode greedy`
- **Top N rules summary** at end of run:
  - `--select-mode frequency` → ranked by GPU frequency (unchanged)
  - `--select-mode greedy` → ranked by greedy / local-search selection order
    (shows marginal gain + original GPU freq)
- README updated with local-search flags and example

### Tests

- 7 new unit tests for `local_search_improve` in `tests/test_selection.py`
  - empty / already-optimal / improving swap / size preservation /
    max-swaps budget / cost_alpha / plain-dict coverage
- Full suite: **177 passed**

### Files touched

| File | Change |
|------|--------|
| `rulest/selection.py` | +`local_search_improve()`; streaming coverage; keep deeper rules in coverage eval |
| `rulest/cli.py` | CLI flags, banner, wiring after CELF, top-N display by mode |
| `rulest/coverage_store.py` | **new** — extracted store implementations |
| `rulest/common.py` | `SELECTION_DISK_THRESHOLD`, raised minimize threshold |
| `rulest/io_utils.py` | streaming wordlist load |
| `tests/test_selection.py` | local-search unit tests |
| `README.md` | flags + usage example |
| `CHANGELOG.md` | this file |
