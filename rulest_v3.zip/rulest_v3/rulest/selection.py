"""
Post-processing — marginal-coverage rule SELECTION.

minimize_by_signature() (see minimize.py) answers "which rules are
functionally distinct?" — it says nothing about which of those distinct
rules are actually worth keeping for a given budget. Sorting by raw GPU
frequency (the historical default) picks rules that individually recover
the most target words, but says nothing about *overlap*: two high-frequency
rules can recover almost the same subset of the target list, in which case
keeping both wastes budget that a lower-frequency-but-orthogonal rule would
have spent better.

The functions below implement "select by marginal coverage, not by summed
score": build C(r) = {DISTINCT TARGET WORDS actually recovered by rule r}
against the real target wordlist, then run a lazy greedy (CELF) set-cover
selection over that universe. The GPU bloom-filter evaluation is used as a
fast prefilter, but every bloom-positive (rule, base_word) pair is resolved
through the exact verification kernel before it enters C(r). This makes the
CELF objective semantically match the reported target recovery and removes
bloom false positives from the optimization itself.
"""
import time
import heapq
import shutil

import numpy as np
from tqdm import tqdm

from .common import log_info, log_warn, log_section, bold, green, cyan, _fmt_speed
from .genetic import GeneticRuleEvolver

# Shared empty-hit sentinel (avoids allocating a fresh empty array per rule
# with zero coverage — there are often many of these in a large pool).
_EMPTY_HITS = np.empty(0, dtype=np.int32)


def evaluate_full_coverage(gpu_engine, base_words, target_words, rules, max_depth, batch_size=4000):
    """GPU-evaluate every candidate rule and return *target* coverage.

    The returned matrix is ``{rule_str: np.ndarray[int32]}``, where each
    integer is an index into the UNIQUE ``target_words`` sequence.  A rule's
    coverage therefore means "which distinct target words does this rule
    actually recover?" rather than "which base words happened to produce a
    bloom-filter hit?".

    The GPU bloom-filter kernel is still used as the cheap first-stage
    prefilter.  Every bloom-positive ``(rule, base_word)`` pair is then passed
    through ``verify_pairs_exact`` and its actual output is mapped back to a
    target-word id.  Bloom false positives are consequently excluded before
    CELF sees the coverage matrix.

    This extra verification is intentional: a set-cover objective is only
    semantically correct if its universe is the thing we actually want to
    maximize — distinct recovered target words.  Tracking base-word indices
    is only a proxy and can overvalue rules whose hits collapse onto the same
    target password.
    """
    log_section("SELECTION — GPU Coverage Evaluation")
    rule_list = [r for r in rules if r and r != ':']

    # The GPU chain kernel's found-string/index buffers are sized for
    # exactly MAX_CHAIN_DEPTH tokens (see kernel_source.py's
    # find_rule_chains_gpu / _compute_chain_seqs). A candidate longer than
    # that gets silently truncated on the GPU side: _compute_chain_seqs()
    # only encodes the first `max_depth` tokens, so the kernel executes
    # (and reports back) a chain string that is a strict PREFIX of the
    # candidate — a different, shorter rule than the one actually asked
    # about. Two problems follow from ever letting that happen: (1) the
    # returned prefix string doesn't match the full candidate string used
    # as the dict key on the Python side, raising KeyError deep inside
    # _eval_on_engine(); and (2) even if it didn't crash, attributing a
    # coverage hit to the full N-token candidate when only its first
    # max_depth tokens actually ran would be silently wrong data — the
    # credited rule was never really evaluated. So over-length candidates
    # are excluded up front (not truncated) and reported, rather than
    # letting the kernel's defensive truncation leak into the results.
    effective_max_depth = max_depth
    engine_mcd = getattr(gpu_engine, 'params', {}).get('MAX_CHAIN_DEPTH') if hasattr(gpu_engine, 'params') else None
    if isinstance(engine_mcd, int) and engine_mcd > 0:
        effective_max_depth = min(effective_max_depth, engine_mcd)

    oversized = [r for r in rule_list if len(r.split()) > effective_max_depth]
    if oversized:
        rule_list = [r for r in rule_list if len(r.split()) <= effective_max_depth]
        log_warn(
            f"[COVERAGE] Excluded {bold(str(len(oversized)))} candidate(s) longer than "
            f"max depth {effective_max_depth} — the GPU kernel can only execute the first "
            f"{effective_max_depth} tokens of a chain, so evaluating them would silently "
            f"credit a truncated prefix rule instead of the actual candidate."
        )

    rule_list.sort(key=lambda r: len(r.split()))
    n = len(rule_list)
    log_info(f"[COVERAGE] Candidates   : {bold(str(n))}")
    log_info(f"[COVERAGE] Base words   : {bold(str(len(base_words)))}")
    log_info(f"[COVERAGE] Target words : {bold(str(len(target_words)))}")
    if n == 0 or not target_words or not base_words:
        return {}

    try:
        import resource
        def _rss_mb():
            return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    except ImportError:
        def _rss_mb():
            return -1.0

    # Preserve first-seen order while giving CELF a compact universe of
    # distinct target strings.  The caller's target list may contain duplicates.
    unique_targets = list(dict.fromkeys(target_words))
    target_to_id = {word: i for i, word in enumerate(unique_targets)}

    # A throwaway evolver is used only as the existing GPU-dispatch shim.
    evolver = GeneticRuleEvolver(
        gpu_engine, base_words, rule_pool=[], max_depth=max(2, max_depth)
    )
    evolver.active_words = base_words

    coverage = {}
    ncols = shutil.get_terminal_size((80, 24)).columns
    t0 = time.time()
    with tqdm(total=n, desc=green("  Coverage eval"), unit="rule", ncols=ncols,
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}") as pbar:
        for i in range(0, n, batch_size):
            chunk = rule_list[i:i + batch_size]
            population = [tuple(r.split()) for r in chunk]

            # verify_pairs_exact() (below, previous iteration) narrows
            # gpu_engine.rule_index to whatever chains IT was last called
            # with. evaluate_population() needs rule_index to cover every
            # token in THIS batch, or unrecognized tokens silently resolve
            # to -1 and the GPU kernel reports a corrupted, truncated chain
            # string that doesn't match any key in hit_words (KeyError).
            # Rebuild it fresh for this batch before dispatching.
            gpu_engine.prepare_rule_pool(chunk)
            hit_words = evolver.evaluate_population(population)

            # The bloom kernel only tells us which base words produced a
            # probable hit.  Recompute those pairs with the exact verification
            # kernel so the coverage universe is target_words, not base_words.
            pairs = []
            for ci, tok in enumerate(population):
                cs = ' '.join(tok)
                hits = hit_words.get(cs)
                if hits:
                    pairs.extend((ci, int(wi)) for wi in hits)

            exact_outputs = gpu_engine.verify_pairs_exact(
                base_words, chunk, pairs, batch_size=batch_size
            ) if pairs else []

            per_rule_targets = [set() for _ in chunk]
            for (ci, _wi), output in zip(pairs, exact_outputs):
                if output is None:
                    continue
                target_id = target_to_id.get(output)
                if target_id is not None:
                    per_rule_targets[ci].add(target_id)

            for r, ids in zip(chunk, per_rule_targets):
                coverage[r] = (
                    np.fromiter(sorted(ids), dtype=np.int32, count=len(ids))
                    if ids else _EMPTY_HITS
                )

            # One-shot pass: do not let the GA hit cache grow with the entire
            # candidate pool.
            evolver._hit_cache.clear()
            pbar.update(len(chunk))
            elapsed = time.time() - t0
            spd = _fmt_speed(pbar.n / elapsed if elapsed > 0 else 0, "rules")
            avg_depth = sum(len(r.split()) for r in chunk) / len(chunk)
            pbar.set_postfix({"spd": green(spd), "depth": f"{avg_depth:.1f}",
                               "rss": f"{_rss_mb():.0f}MB"}, refresh=False)

    covered_any = sum(1 for c in coverage.values() if len(c))
    total_recovered = len(set().union(*(set(c.tolist()) for c in coverage.values() if len(c)))) if covered_any else 0
    log_info(
        f"[COVERAGE] {green('Done')}  rules with >=1 exact target hit: "
        f"{bold(cyan(str(covered_any)))}/{n}; distinct targets reachable: "
        f"{bold(cyan(str(total_recovered)))}/{len(unique_targets)}"
    )
    return coverage


def select_rules_by_marginal_coverage(coverage, counts, n_target_words, budget=None, cost_alpha=0.0):
    """Lazy greedy (CELF) submodular set-cover selection.

    Instead of ranking rules by their own score and summing:
        score(r1) + score(r2) + ... + score(rk)
    this maximizes the *union* actually recovered:
        | C(r1) u C(r2) u ... u C(rk) |
    by repeatedly picking the rule with the largest NEW recovery given what's
    already selected. Naive greedy is O(rules x budget); CELF exploits
    submodularity (marginal gains only ever shrink as the covered set grows)
    to lazily re-validate the heap top instead of rescanning every rule each
    step, which is what makes this tractable at 150k-1.7M candidate rules.

    `coverage`: {rule: np.ndarray(int32 word_idx)} from evaluate_full_coverage().
    `counts`:   {rule: raw_gpu_frequency} — used only to break ties
                deterministically, never as the optimization objective.
    `n_target_words`: size of the boolean "covered" mask — number of
                unique target words. Coverage indices are target-word ids.
    `budget`:   max rules to select; None = run to saturation (stop once no
                remaining rule adds anything).
    `cost_alpha`: gain(r) = new_recovery(r) / depth(r)**cost_alpha. 0 = pure
                marginal-coverage greedy. >0 favors shorter/cheaper chains
                among rules with similar marginal gain.

    Coverage sets are tracked as a single numpy boolean mask over target_words
    (updated in place with fancy indexing) rather than Python set unions —
    with 150k-1.7M candidates this avoids repeated hashing and boxed-int set
    churn, matching the same memory rationale as switching
    evaluate_full_coverage's storage from frozenset to int32 arrays.

    Returns (selected, covered_mask):
        selected     -> list of (rule, marginal_gain) in selection order (best first)
        covered_mask -> np.ndarray(bool), True at every target-word id
                        recovered by `selected`
    """
    def cost(r):
        if cost_alpha <= 0:
            return 1.0
        depth = max(1, len(r.split()))
        return depth ** cost_alpha

    log_section("SELECTION — Greedy Marginal Coverage (CELF)")
    rule_order = sorted(
        (r for r, c in coverage.items() if len(c)),
        key=lambda r: (-counts.get(r, 0), len(r.split()), r)
    )
    limit = budget if budget else len(rule_order)
    log_info(f"[SELECT] Candidates (with >=1 hit) : {bold(str(len(rule_order)))}")
    log_info(f"[SELECT] Budget                    : {bold(str(limit) if budget else 'unbounded (saturation)')}")
    log_info(f"[SELECT] Cost alpha                : {bold(str(cost_alpha))}")

    heap = []
    for r in rule_order:
        c = coverage[r]
        heapq.heappush(heap, (-(len(c) / cost(r)), r, 0))

    selected = []
    covered_mask = np.zeros(n_target_words, dtype=bool)
    n_covered = 0
    stamp = 0
    ncols = shutil.get_terminal_size((80, 24)).columns
    with tqdm(total=limit, desc=green("  Greedy select"), unit="rule", ncols=ncols,
              bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}] {postfix}") as pbar:
        while heap and len(selected) < limit:
            neg_gain, r, s = heapq.heappop(heap)
            if s == stamp:
                gain = -neg_gain
                if gain <= 0:
                    break  # saturation: nothing left adds any new coverage
                selected.append((r, gain))
                covered_mask[coverage[r]] = True
                n_covered = int(covered_mask.sum())
                stamp += 1
                pbar.update(1)
                pbar.set_postfix({"recovered": cyan(str(n_covered))}, refresh=False)
                continue
            c = coverage[r]
            new_gain = int(np.count_nonzero(~covered_mask[c])) / cost(r)
            if new_gain <= 0:
                continue
            heapq.heappush(heap, (-new_gain, r, stamp))

    log_info(f"[SELECT] {green('Done')}  rules selected: {bold(cyan(str(len(selected))))}  "
              f"recovered: {bold(cyan(str(n_covered)))}")
    return selected, covered_mask


def compute_exact_recovery(target_words, selected, coverage):
    """Return exact recovery from the target-word coverage matrix.

    ``evaluate_full_coverage`` now resolves every bloom-positive pair through
    the exact GPU verification kernel before building ``coverage``.  Therefore
    the coverage matrix is already zero-FPR and directly represents distinct
    target-word ids.  No second GPU pass is necessary here; this function is
    kept as the explicit reporting hook used by ``--exact-recovery``.

    Returns ``(n_exact_covered, recovery_pct, matched_target_strings)``.
    """
    log_section("SELECTION — Exact Recovery (--exact-recovery)")
    unique_targets = list(dict.fromkeys(target_words))
    if not selected or not unique_targets:
        log_info("[EXACT] No selected rules or target words — nothing to verify")
        return 0, 0.0, set()

    target_ids = set()
    for rule, _gain in selected:
        hits = coverage.get(rule)
        if hits is not None and len(hits):
            target_ids.update(int(i) for i in hits)

    matched = {unique_targets[i] for i in target_ids if 0 <= i < len(unique_targets)}
    recovery_pct = len(matched) / len(unique_targets)
    log_info(
        f"[EXACT] {green('Done')}  distinct target_words cracked: "
        f"{bold(cyan(str(len(matched))))}/{len(unique_targets)} ({recovery_pct:.2%})"
    )
    return len(matched), recovery_pct, matched

